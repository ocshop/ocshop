<?php
// *	@copyright	OPENCART.PRO 2011 - 2020.
// *	@forum      http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

	// усталёўваем мову краіны
	$warning = false;

	$post = array(
		'name'		 => 'Українська мова',
		'code'		 => 'uk-ua',
		'locale'	 => 'uk_UA.UTF-8,uk_UA,ukrainian',
		'sort_order' => 220,
		'status'	 => 1
	);

	$this->load->model('localisation/language');

	$language_info = $this->model_localisation_language->getLanguageByCode($post['code']);

	if (!isset($this->request->get['language_id'])) {
		if ($language_info) {
			$warning = 'pisec';
		}
	} else {
		if ($language_info && ($this->request->get['language_id'] != $language_info['language_id'])) {
			$warning = 'pisec';
		}
	}

	if (!$warning) {
		$this->model_localisation_language->addLanguage($post);
	}

	// усталёўваем правільную назву краіны
	$warning = false;

	$this->load->model('localisation/country');

	$country_info = $this->model_localisation_country->getCountry(220);

	if ($country_info['name'] == 'Украина') {
		$post = $country_info;
		$post['name'] = 'Україна';
	} else {
		$warning = 'pisec';
	}

	if (!$warning) {
		$this->model_localisation_country->editCountry(220, $post);
	}

	// усталёўваем правільную назву вабласцей
	$warning = false;

	$zone_names = array(
		'Вінницька'         => 'Винницкая область',
		'Волинська'         => 'Волынская область',
		'Дніпропетровська'  => 'Днепропетровская область',
		'Донецька'          => 'Донецкая область',
		'Житомирська'       => 'Житомирская область',
		'Закарпатська'      => 'Закарпатская область',
		'Запорізька'        => 'Запорожская область',
		'Івано-Франківська' => 'Ивано-Франковская область',
		'Київ'              => 'Киев',
		'Київська'          => 'Киевская область',
		'Кіровоградська'    => 'Кировоградская область',
		'Крим'              => 'Крым',
		'Луганська'         => 'Луганская область',
		'Львівська'         => 'Львовская область',
		'Миколаївська'      => 'Николаевская область',
		'Одеська'           => 'Одесская область',
		'Полтавська'        => 'Полтавская область',
		'Рівненська'        => 'Ровненская область',
		'Севастопольська'   => 'Севастополь',
		'Сумська'           => 'Сумская область',
		'Тернопільська'     => 'Тернопольская область',
		'Харківська'        => 'Харьковская область',
		'Херсонська'        => 'Херсонская область',
		'Хмельницька'       => 'Хмельницкая область',
		'Черкаська'         => 'Черкасская область',
		'Чернівецька'       => 'Черновицкая область',
		'Чернігівська'      => 'Черниговская область'
	);

	$this->load->model('localisation/zone');

	$zones = $this->model_localisation_zone->getZonesByCountryId(220);

	foreach ($zones as $zone) {
		if (in_array($zone['name'], $zone_names)) {
			$post = $zone;
			$post['name'] = array_search($zone['name'], $zone_names);

			$this->model_localisation_zone->editZone($zone['zone_id'], $post);
		} else {
			$warning = 'pisec';
		}
	}