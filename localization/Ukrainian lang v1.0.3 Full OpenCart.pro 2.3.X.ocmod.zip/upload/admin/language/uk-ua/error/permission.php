<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']   = 'Доступ заборонено!';

// Text
$_['text_permission'] = 'У Вас немає прав для доступу до цієї сторінки. Якщо вона Вам потрібна, зверніться до адміністратора. У тому випадку якщо Ви входите в групу Адміністраторів  відредагуйте права групи.';