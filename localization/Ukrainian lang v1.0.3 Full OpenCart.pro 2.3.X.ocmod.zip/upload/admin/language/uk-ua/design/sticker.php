<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']      = 'Промо Стікери';

// Text
$_['text_success']       = 'Промо Стікери успішно оновлені!';
$_['text_default']       = 'За замовчуванням';
$_['text_image_manager'] = 'Управління зображеннями';
$_['text_browse']        = 'Перегляд файлів';
$_['text_clear']         = 'Прибрати зображення';
$_['text_list']          = 'Список Стікеров';
$_['text_add']           = 'Додати Стікер';
$_['text_edit']          = 'Редагування';

// Column
$_['column_image']       = 'Зображення';
$_['column_name']        = 'Назва стікеру';
$_['column_status']      = 'Статус';
$_['column_action']      = 'Дія';

// Entry
$_['entry_name']         = 'Назва стікеру:';
$_['entry_image']        = 'Зображення:';
$_['entry_status']       = 'Статус:';

// Error
$_['error_permission']   = 'Вы не маєте прав для змінення стікерів!';
$_['error_name']         = 'Назва стікера повинна бути від 3 до 64 символів!';
$_['error_title']        = 'Заголовок повинен бути від 2 до 64 символів!';
$_['error_default']      = 'Цей стікер не може бути видален, оскільки він використовується в магазині за замовчуванням!';
$_['error_product']      = 'Цей стікер не може бути видален, оскільки він використовується %s товаром(ами)!';
$_['error_category']     = 'Цей стікер не може бути видален, оскільки він використовується %s категорією(ями)!';
$_['error_information']  = 'Цей стікер не може бути видален, оскільки він використовується %s сторінкою(ами)!';
?>