<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']	   		= 'Ліцензія opencart.pro';
$_['text_license']        	= 'Ліцензія';

$_['text_pro_license']   	= 'Ліцензійний код:';
$_['text_order_id']   		= 'Номер замовлення:';

$_['text_help']   			= 'Для отримання ліцензійного коду, відправте запит особистим повідомленням до <a href="http://forum.opencart.pro/profile/1-admin/" target="_blank">@admin</a> на <a href="http://forum.opencart.pro/" target="_blank">forum.opencart.pro</a>. Придбати ліцензію можно на <a href="https://liveopencart.ru/opencart-moduli-shablony/opencart-pro/opencart-pro-2-x" target="_blank">Liveopencart.ru</a>';

$_['entry_license_code']    = 'Введіть ліцензію';
$_['entry_order_id']   		= 'Введіте номер';


$_['error_permission']      = 'У вас недостатньо прав для редагування даного розділу!';
$_['error_pro_license']     = 'Введіть код ліцензії!';
$_['error_order_id']     	= 'Введіть номер покупки!';
$_['wrong_turbo_license']   = 'Ви ввели неправильний ліцензійний код!';

