<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['text_search_options']           = 'Опції пошуку';
$_['text_catalog']                  = 'Каталог';
$_['text_customers']                = 'Користувачі';
$_['text_orders']                   = 'Замовлення';
$_['text_products']                 = 'Товари';
$_['text_categories']               = 'Категорії';
$_['text_manufacturers']            = 'Виробнинки';
$_['text_catalog_placeholder']      = 'Назва, Код товару, SKU';
$_['text_customers_placeholder']    = 'Прізвище, Ім\'я, E-Mail';
$_['text_orders_placeholder']       = 'Номер замовлення, Номер рахунку, Прізвище, Ім\'я, E-mail';
$_['text_search_placeholder']       = 'Пошук';
$_['text_no_result']                = '- Немає результатів -';
$_['text_order_id']                 = 'Номер замовлення: ';