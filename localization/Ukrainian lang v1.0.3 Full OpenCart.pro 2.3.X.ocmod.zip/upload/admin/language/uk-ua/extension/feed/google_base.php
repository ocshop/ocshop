<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    = 'Google Base';

// Text
$_['text_feed']        = 'Канали просування';
$_['text_success']     = 'Налаштування успішно змінені!';
$_['text_edit']        = 'Редагування';
$_['text_import']      = 'Щоб завантажити останній список категорій Google <a href="https://support.google.com/merchants/answer/160081?hl=en" target="_blank" class="alert-link">натисніть тут</a> і виберіть класифікацію з числовими ідентифікаторами у текстовому форматі (.txt). Завантажити за допомогою зеленої кнопки імпорту.';

// Column
$_['column_google_category'] = 'Google категорія';
$_['column_category']        = 'Категорія';
$_['column_action']          = 'Дія';

// Entry
$_['entry_google_category'] = 'Google Категорія';
$_['entry_category']        = 'Категорія';
$_['entry_status']     = 'Статус';
$_['entry_data_feed']  = 'Адреса';

// Error
$_['error_permission'] = 'У вас недостатньо прав для внесення змін!';
$_['error_upload']          = 'Файл не може бути завантажений!';
$_['error_filetype']        = 'Невірний формат файлу!';