<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']      = 'Яндекс.Маркет';

// Text
$_['text_extension']   	 = 'Розширення';
$_['text_feed']          = 'Канали просування';
$_['text_success']       = 'Налаштування успішно змінені!';
$_['text_edit']        	 = 'Редагування';

// Entry
$_['entry_status']       = 'Статус';
$_['entry_data_feed']    = 'Адреса';
$_['entry_shopname']     = 'Назва магазину';
$_['entry_company']      = 'Компанія';
$_['entry_category']     = 'Категорії';
$_['entry_currency']     = 'Валюта пропозицій';
$_['entry_in_stock']     = 'Статус &quot;У наявності&quot;';
$_['entry_out_of_stock'] = 'Статус &quot;Немає в наявності&quot;';

//Help
$_['help_shopname']           = 'Коротка назва магазину (назва, яка виводиться у списку знайдених на Яндекс.Маркеті товарів. Не повинна містити більше 20 символів).';
$_['help_company']            = 'Повна назва компанії, яка є володарем магазина. Не публікується, використовується для внутрішньої ідентифікації.';
$_['help_category']           = 'Відмітьте категорії з яких потрібно експортувати пропозиції для Яндекс.Маркета.';
$_['help_currency']           = 'Яндекс.Маркет приймає пропозиції у валюті RUR, RUB или UAH. Виберіть валюту в якій будуть передаватися пропозиції.';
$_['help_in_stock']           = 'При залишку на складі 0';
$_['help_out_of_stock']       = 'При залишку на складі 0';
$_['help_yandex_market']      = 'Тема на <a target="_blank" href="http://forum.opencart.pro/index.php?/files/file/40-yandexmarket-20/">Форумі</a>';

// Error
$_['error_permission']   	  = 'У вас недостатньо прав для внесення змін!';
?>