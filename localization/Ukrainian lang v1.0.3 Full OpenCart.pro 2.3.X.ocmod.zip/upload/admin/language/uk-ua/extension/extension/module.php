<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    = 'Модулі';

// Text
$_['text_success']     = 'Налаштування успішно змінені!';
$_['text_layout']      = 'Після установки і налаштування модуля його необхідно додати у разділі <a href="%s" class="alert-link">Дизайн - Макети</a>!';
$_['text_add']         = 'Додати';
$_['text_list']        = 'Список модулей';

// Column
$_['column_name']      = 'Назва модуля';
$_['column_action']    = 'Дія';

// Entry
$_['entry_code']       = 'Модуль';
$_['entry_name']       = 'Назва модуля';

// Error
$_['error_permission'] = 'У вас недостатньо прав для внесення змін!';
$_['error_name']       = 'Назва повинна містити від 3 до 64 символів!';
$_['error_code']       = 'Необхідний модуль!';