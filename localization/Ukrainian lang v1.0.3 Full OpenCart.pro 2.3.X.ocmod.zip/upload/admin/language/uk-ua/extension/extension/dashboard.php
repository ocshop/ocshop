<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Панель стану';

// Text
$_['text_success']      = 'Налаштування успішно змінені!';
$_['text_list']         = 'Список віджетів';

// Column
$_['column_name']       = 'Назва віджету';
$_['column_width']      = 'Ширина';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action']     = 'Дія';

// Error
$_['error_permission']  = 'У вас недостатньо прав для внесення змін!';