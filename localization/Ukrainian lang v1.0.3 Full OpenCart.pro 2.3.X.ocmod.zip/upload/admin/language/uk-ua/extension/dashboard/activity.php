<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']                = 'Остання активність';

// Text
$_['text_extension']               = 'Розширення';
$_['text_success']                 = 'Налаштування успішно змінені!';
$_['text_edit']                    = 'Редагування';
$_['text_customer_address_add']    = '<a href="customer_id=%d">%s</a> - додана нова адреса.';
$_['text_customer_address_edit']   = '<a href="customer_id=%d">%s</a> - оновлено адресу.';
$_['text_customer_address_delete'] = '<a href="customer_id=%d">%s</a> - видалена одна з адрес.';
$_['text_customer_edit']           = '<a href="customer_id=%d">%s</a> - оновлено інформацію акаунта.';
$_['text_customer_forgotten']      = '<a href="customer_id=%d">%s</a> - запит нового паролю.';
$_['text_customer_reset']          = '<a href="customer_id=%d">%s</a> - скинутий пароль облікового запису.';
$_['text_customer_login']          = '<a href="customer_id=%d">%s</a> - виконано вхід.';
$_['text_customer_password']       = '<a href="customer_id=%d">%s</a> - оновлено пароль.';
$_['text_customer_register']       = '<a href="customer_id=%d">%s</a> - реєстрація акаунта.';
$_['text_customer_return_account'] = '<a href="customer_id=%d">%s</a> - запит повернення товару.';
$_['text_customer_return_guest']   = '%s - запит повернення товару.';
$_['text_customer_order_account']  = '<a href="customer_id=%d">%s</a> <a href="order_id=%d"> - створено нове замовлення</a>.';
$_['text_customer_order_guest']    = '%s <a href="order_id=%d"> - створено нове замовлення</a>.';
$_['text_affiliate_edit']          = '<a href="affiliate_id=%d">%s</a> - оновлено інформацію акаунта.';
$_['text_affiliate_forgotten']     = '<a href="affiliate_id=%d">%s</a> - запитано новий пароль.';
$_['text_affiliate_login']         = '<a href="affiliate_id=%d">%s</a> - виконано вхід.';
$_['text_affiliate_password']      = '<a href="affiliate_id=%d">%s</a> - оновлено пароль.';
$_['text_affiliate_payment']       = '<a href="affiliate_id=%d">%s</a> - оновлені деталі оплати.';
$_['text_affiliate_register']      = '<a href="affiliate_id=%d">%s</a> - зареєстровано новий акаунт.';

// Entry
$_['entry_status']                 = 'Статус';
$_['entry_sort_order']             = 'Порядок сортування';
$_['entry_width']                  = 'Ширина';

// Error
$_['error_permission']             = 'У вас недостатньо прав для внесення змін!';