<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'eBay Listing';

// Text
$_['text_module']       = 'Модулі';
$_['text_success']      = 'Налаштування успішно змінені!';
$_['text_edit']        	= 'Редагування';
$_['text_list']         = 'Layout List';
$_['text_register']     = 'You need to register and enable OpenBay Pro for eBay!';
$_['text_about'] 		= 'The eBay display module allows you to display products from your eBay account directly on your website.';
$_['text_latest']       = 'Новинки';
$_['text_random']       = 'Random';

// Entry
$_['entry_name']        = 'Назва модулю';
$_['entry_username']    = 'eBay username';
$_['entry_keywords']    = 'Search Keywords';
$_['entry_description'] = 'Include Description Search';
$_['entry_limit']       = 'Ліміт';
$_['entry_length']      = 'Довжина';
$_['entry_width']       = 'Ширина';
$_['entry_height']      = 'Висота';
$_['entry_site']   		= 'eBay Site';
$_['entry_sort']   		= 'Sort by';
$_['entry_status']   	= 'Статус';

// Error
$_['error_permission']  = 'У вас недостатньо прав для внесення змін!';
$_['error_name']        = 'Назва повинна містити від 3 до 64 символів!';
$_['error_width']       = 'Укажіть Ширину!';
$_['error_height']      = 'Укажіть Висоту!';