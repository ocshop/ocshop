<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    			 = 'Custom Footer';

// Text
$_['text_extension']   			 = 'Розширення';
$_['text_success']     			 = 'Налаштування успішно змінені!';
$_['text_edit']        			 = 'Налаштування модулю';

// Entry
$_['entry_welcome']              = 'Привітання:';
$_['entry_address']              = 'Адреса магазину:';
$_['entry_maps']       			 = 'Яндекс мапа:';
$_['entry_email']                = 'E-Mail:';
$_['entry_telephone']            = 'Телефон-1:';
$_['entry_telephone2']           = 'Телефон-2:';
$_['entry_telephone3']           = 'Телефон-3:';
$_['entry_vk']                   = 'Вконтакті:';
$_['entry_fb']                   = 'Фейсбук:';
$_['entry_googleplus']           = 'Google+:';
$_['entry_youtube']              = 'Youtube:';
$_['entry_twitter']              = 'Twitter:';
$_['entry_time']                 = 'Час работи:';
$_['entry_status']     			 = 'Статус';

// Help
$_['help_maps']        			 = 'Перейдіть <a target="_blank" href="http://api.yandex.ru/maps/tools/constructor/">Конструктор мап</a><br />Ширина: 100% Висота: 220, далі скопіюйте і вставте отриманий код у текстове поле .';

// Error
$_['error_permission'] 			 = 'У Вас немає прав для управління даним модулем!';