<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro

// Heading
$_['heading_title']   	 	= '<img alt="Opencart Turbo" title="Opencart Turbo" src="../admin/view/image/turbo_logo.jpg">';
$_['text_title']       		= 'Opencart Turbo';

// Text
$_['text_module']      		= 'Модулі';
$_['text_success']     		= 'Налаштування успішно змінені!';
$_['text_edit']        		= 'Редагування';
$_['text_tab_image'] 		= 'Налаштування якості зображень';
$_['text_tab_image_h4'] 	= '(для оптимизації оцінки GooglePageSpeed)';
$_['text_order_id'] 		= 'Введіть id покупки';
$_['text_tab_image_info'] 	= '<p><h4>Увага</h4> Для того щоб дані зміни вступили в силу, необхідно очистити кеш зображень. </p> ';
$_['text_basic'] 			= 'Модулі и елементи';
$_['text_global'] 			= 'Глобальний кеш HTML';
$_['text_image'] 			= 'Зображення';
$_['text_experimental'] 	= 'Експериментальні функції';
$_['text_turbo_license'] 	= 'Ліцензія';
$_['text_tab_basic_header'] = 'Налаштування кешування стандартних модулей и елементів';
$_['text_type'] 			= 'Тип елемента';
$_['text_clear'] 			= 'Очистити кеш';
$_['text_tab_global'] 		= 'Глобальний кеш HTML';
$_['text_settings'] 		= 'Налаштування';

// Entry
$_['entry_status']     		= 'Статус';
$_['entry_top_menu'] 		= 'Верхнє меню';
$_['entry_category_list'] 	= 'Список підактегорій в категоріях';
$_['entry_footer_information'] = 'Список посилань на інформаційні сторінки в підвалі';
$_['entry_category_module'] = 'Модуль Категорії';
$_['entry_bestseller_module'] = 'Модуль Хіти продажу';
$_['entry_special_module'] 	= 'Модуль Акції';
$_['entry_latest_module'] = 'Модуль Новинки';
$_['entry_featured_module'] = 'Модуль Рекомендовані';
$_['entry_tab_module'] 		= 'Змінити модель отримання останніх товарів для модуля Tab (немає в оригінальному Opencart)';
$_['entry_сount_off'] 		= 'Відключити підрахунок товарів (ви не зможете подивитися кількість переглядів у системі, але для навантажених магазинів - рекомендується';
$_['entry_cache_expires'] 	= 'Час життя кеша (сек)';
$_['entry_skipped_words'] 	= 'Вийняток:';
$_['entry_mobile_detect'] 	= 'Увімкнути підтримку визначення мобільних пристроїв';
$_['entry_turborate_monitor'] = 'Увімкнути <span style="color:red">TURBORATE MONITOR</span> (видно тільки для адміністраторів магазину)';
$_['entry_license_code'] = 'ліцензійний код';
$_['entry_order_id'] 		= 'id покупки';
$_['entry_jpg_image'] 		= 'Якість зображень JPG (від 0 до 100) 100 - найкраще';
$_['entry_png_image'] 		= 'Ступінь стиснення PNG: від 0 (немає стиснення) до 9';


// Error
$_['error_permission'] 		= 'У вас недостатньо прав для внесення змін!';
$_['wrong_turbo_license'] 	= 'Будь ласка активуйте ліцензію для збірки Opencart.pro';
