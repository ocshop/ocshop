<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    = 'Слайдшоу';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Налаштування успішно змінені!';
$_['text_edit']        = 'Редагування';

// Entry
$_['entry_name']       = 'Назва модулю';
$_['entry_banner']     = 'Банер';
$_['entry_width']      = 'Ширина';
$_['entry_height']     = 'Висота';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас недостатньо прав для внесення змін!';
$_['error_name']       = 'Назва повинна містити від 3 до 64 символів!';
$_['error_width']      = 'Укажіть Ширину!';
$_['error_height']     = 'Укажіть Висоту!';