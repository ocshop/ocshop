<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     		  = 'Кеш менеджер';

// Text
$_['text_extension']   			  = 'Розширення';
$_['text_module']       		  = 'Модулі';
$_['text_edit']         		  = 'Редагування';
$_['text_success']      		  = 'Кеш видалено!';
$_['text_success_img']         	  = 'Кеш зображень видалено!';
$_['text_success_system']      	  = 'Системный Кеш видалено!';
$_['text_default']      		  = 'За замовчуванням';

$_['button_clearallcache']        = 'Видалити весь Кеш';
$_['button_clearcache']           = 'Видалити Кеш зображень';
$_['button_clearsystemcache']     = 'Видалити системний Кеш';

// Column
$_['column_description']          = 'Опис';
$_['column_action']     	      = 'Дія';

// Entry
$_['image_description']       	  = 'Видалення Кешу зображень';
$_['system_description']     	  = 'Видалення Кешу системных файлів';

// Error 
$_['error_permission']  		  = 'У Вас немає прав для управління Кешем!';
?>