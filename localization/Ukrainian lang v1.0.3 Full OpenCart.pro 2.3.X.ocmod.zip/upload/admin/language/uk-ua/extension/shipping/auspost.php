<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']      = 'Australia Post';

// Text
$_['text_shipping']      = 'Доставка';
$_['text_success']       = 'Налаштування успішно змінені!';
$_['text_edit']          = 'Редагування';

// Entry
$_['entry_postcode']     = 'Поштовий індекс';
$_['entry_express']      = 'Express Postage';
$_['entry_standard']     = 'Standard Postage';
$_['entry_display_time'] = 'Display Delivery Time';
$_['entry_weight_class'] = 'Одиниця виміру ваги';
$_['entry_tax_class']    = 'Клас податку';
$_['entry_geo_zone']     = 'Географічна зона';
$_['entry_status']       = 'Статус';
$_['entry_sort_order']   = 'Порядок сортування';

// Help
$_['help_display_time']  = 'Do you want to display the shipping time? (e.g. Ships within 3 to 5 days)';
$_['help_weight_class']  = 'Set to grams.';

// Error
$_['error_permission']   = 'У вас недостатньо прав для внесення змін!';
$_['error_postcode']     = 'Post Code must be 4 digits!';