<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    = 'Доставка по городу Citylink';

// Text
$_['text_shipping']    = 'Доставка';
$_['text_success']     = 'Налаштування успішно змінені!';
$_['text_edit']        = 'Редагування';

// Entry
$_['entry_rate']       = 'Тарифи доставки';
$_['entry_tax_class']  = 'Клас податку';
$_['entry_geo_zone']   = 'Географічна зона';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Help
$_['help_rate']        = 'Введіть пари вага:вартість (значення - до 5.2 десятичних разрядів, наприклад: 12345.67). Приклад: .1:1,.25:1.27 - вага до 0.1 кг буде коштувати 1.00 (в одиницях валюти за замовчуванням), Вага від 0.1 до 0.25 кг буде коштувати 1.27. Не вписуйте кг або інші символи.';

// Error
$_['error_permission'] = 'У вас недостатньо прав для внесення змін!';