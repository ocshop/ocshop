<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']        = 'Установка розширень';

// Text
$_['text_upload']          = 'Ви можете додати свої розширення';
$_['text_success']         = 'Розширення успішно встановлено!';
$_['text_unzip']           = 'Розпакування файлів!';
$_['text_ftp']             = 'Копіювання файлів!';
$_['text_sql']             = 'Оновлення база даних!';
$_['text_xml']             = 'Застосування модифікатора!';
$_['text_php']             = 'Виконання PHP!';
$_['text_remove']          = 'Видалення тимчасових файлів!';
$_['text_clear']           = 'Усі тимчасові файли успішно видалені!';

// Entry
$_['entry_upload']         = 'Завантажити файл';
$_['entry_overwrite']      = 'Файли, які будуть перезаписані';
$_['entry_progress']       = 'Процес';

// Help
$_['help_upload']          = 'Розширення модифікатора або модуля повинно бути .ocmod.zip або .ocmod.xml';

// Error
$_['error_permission']     = 'У вас недостатньо прав для внесення змін!';
$_['error_temporary']      = 'Існують тимчасові файли, які потребують видалення. Натисніть кнопку очистити, щоб видалити їх!';
$_['error_upload']         = 'Файл не був завантажен!';
$_['error_filetype']       = 'Неправильний тип файлу!';
$_['error_file']           = 'Файл не знайден!';
$_['error_unzip']          = 'Zip архів не вдалося розпакувати!';
$_['error_code']           = 'Модифікація потребує унікальний ідентифікаційний код!';
$_['error_exists']         = 'Модифікація %s використовує той же ідентифікаційний код, котрий ви хочете завантажити!';
$_['error_directory']      = 'Каталог, що містить файли для завантаження не знайден!';
$_['error_ftp_status']     = 'FTP повинен бути включен в Налаштуваннях';
$_['error_ftp_connection'] = 'Не вдалося підключитися до %s:%s';
$_['error_ftp_login']      = 'Не вдалося авторизуватися як %s';
$_['error_ftp_root']       = 'Не вдалося обрати директорію  %s';
$_['error_ftp_directory']  = 'Не вдалося змінити директорію %s';
$_['error_ftp_file']       = 'Не вдалося завантажити файли %s';