<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

$_['heading_title']    = 'Google Аналітикс';

// Text
$_['text_extension']   = 'Розширення';
$_['text_analytics']   = 'Аналітикс';
$_['text_success']	   = 'Налаштування успішно змінені!';
$_['text_edit']        = 'Налаштування Google Аналитикс';
$_['text_signup']      = 'Увійдіть у Ваш <a href="http://www.google.com/analytics/" target="_blank"><u>Google Аналітикс</u></a> і після налаштування додайте сюди виданий код.';

// Entry
$_['entry_code']       = 'Код Google Аналітикс';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас недостатньо прав для внесення змін!';
$_['error_code']	   = 'Необхідний код Google Аналітикс!';