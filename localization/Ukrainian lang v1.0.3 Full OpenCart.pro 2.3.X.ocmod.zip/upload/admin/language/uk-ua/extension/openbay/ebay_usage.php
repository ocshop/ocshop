<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Headings
$_['heading_title']             = 'Usage';
$_['text_openbay']              = 'OpenBay Pro';
$_['text_ebay']                 = 'eBay';

// Text
$_['text_usage']                = 'Your account usage';

// Errors
$_['error_ajax_load']      		= 'Sorry, could not get a response. Try later.';