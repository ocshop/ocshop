<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']					= 'Пошук транзакції';

// Column
$_['tbl_column_date']				= 'Дата';
$_['tbl_column_type']				= 'Тип';
$_['tbl_column_email']				= 'E-Mail';
$_['tbl_column_name']				= 'Им\'я';
$_['tbl_column_transid']			= 'ID транзакції';
$_['tbl_column_status']				= 'Статус';
$_['tbl_column_currency']			= 'Валюта';
$_['tbl_column_amount']				= 'Всього';
$_['tbl_column_fee']				= 'Безкоштовно';
$_['tbl_column_netamt']				= 'Чиста сума';
$_['tbl_column_action']				= 'Дія';

// Text
$_['text_pp_express']				= 'PayPal Express (включая Кредитные и Дебетовые карти)';
$_['text_date_search']				= 'Пошук за датою';
$_['text_searching']				= 'Пошук';
$_['text_name']						= 'Им\'я';
$_['text_buyer_info']				= 'Інформація про покупця';
$_['text_view']						= 'Перегляд';
$_['text_format']					= 'Формат';

// Entry
$_['entry_trans_all']				= 'Усе';
$_['entry_trans_sent']				= 'Відправлено';
$_['entry_trans_received']			= 'Отримано';
$_['entry_trans_masspay']			= 'Mass Pay';
$_['entry_trans_money_req']			= 'Запит грошей';
$_['entry_trans_funds_add']			= 'Надійшли засоби';
$_['entry_trans_funds_with']		= 'Списані засоби';
$_['entry_trans_referral']			= 'Партнер';
$_['entry_trans_fee']				= 'Плата';
$_['entry_trans_subscription']		= 'Subscription';
$_['entry_trans_dividend']			= 'Dividend';
$_['entry_trans_billpay']			= 'Bill Pay';
$_['entry_trans_refund']			= 'Refund';
$_['entry_trans_conv']				= 'Обмін валюти';
$_['entry_trans_bal_trans']			= 'Balance Transfer';
$_['entry_trans_reversal']			= 'Reversal';
$_['entry_trans_shipping']			= 'Доставка';
$_['entry_trans_bal_affect']		= 'Balance Affecting';
$_['entry_trans_echeque']			= 'E Чек';
$_['entry_date']					= 'Дата';
$_['entry_date_start']				= 'Початок';
$_['entry_date_end']				= 'Кінець';
$_['entry_date_to']					= 'Кому';
$_['entry_transaction']				= 'Транзакція';
$_['entry_transaction_type']		= 'Тип';
$_['entry_transaction_status']		= 'Статус';
$_['entry_email']					= 'E-Mail';
$_['entry_email_buyer']				= 'Покупця';
$_['entry_email_merchant']			= 'Отримувача';
$_['entry_receipt']					= 'ID отримувача';
$_['entry_transaction_id']			= 'ID транзакції';
$_['entry_invoice_no']				= 'Номер рахунку';
$_['entry_auction']					= 'Номер позиції аукціону';
$_['entry_amount']					= 'Всього';
$_['entry_recurring_id']			= 'ID періодичного профілю';
$_['entry_salutation']				= 'Привітання';
$_['entry_firstname']				= 'Перший';
$_['entry_middlename']				= 'Середній';
$_['entry_lastname']				= 'Останній';
$_['entry_suffix']					= 'Суфікс';
$_['entry_status_all']				= 'Усі';
$_['entry_status_pending']			= 'Чекає';
$_['entry_status_processing']		= 'Обробка';
$_['entry_status_success']			= 'Успішно';
$_['entry_status_denied']			= 'Відмовлено';
$_['entry_status_reversed']			= 'Повернено';