<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']                    = 'Налаштування блогу';

// Text
$_['text_success']                     = 'Налаштування успішно змінені!';
$_['text_edit']                        = 'Налаштування';
$_['text_article']                     = 'Статті';
$_['text_review']                      = 'Відгуки';

// Entry
$_['entry_article_limit']              = 'Кількість статтей на Вітрині';
$_['entry_article_description_length'] = 'Кількість символів (Вітрина)';
$_['entry_limit_admin']                = 'Кількість статтей в ПС сайту';
$_['entry_article_count']              = 'Кількість статтей в категорії';
$_['entry_blog_menu']                  = 'У верхньому меню';
$_['entry_article_download']           = 'Дозволити скачування файлів';
$_['entry_review']                     = 'Дозволити відгуки';
$_['entry_review_guest']               = 'Відгуки гостей';
$_['entry_review_mail']                = 'Повідомлення на E-Mail про новий виклик';
$_['entry_image_category']             = 'Розмір зображення в описі категорії Блогу';
$_['entry_image_article']              = 'Розмір зображення у списку статтей';
$_['entry_image_related']              = 'Розмір зображення аналогічних статтей, товарів';
$_['entry_width']                      = 'Ширина';
$_['entry_height']                     = 'Висота';
$_['entry_name']                       = 'Назва';
$_['entry_meta_title']                 = 'Мета-тег Title';
$_['entry_html_h1']                    = 'HTML-тег H1';
$_['entry_meta_description']           = 'Мета-тег Description';
$_['entry_meta_keyword']               = 'Мета-тег Keywords';

// Help
$_['help_article_limit'] 	           = 'Кількість статтей на сторінці Список статтей';
$_['help_article_description_length']  = 'Кількість символів в короткому описі статті на сторінці Список статтей';
$_['help_limit_admin']   	           = 'Кількість статтей або категорій на сторінці в ПС сайту.';
$_['help_article_count']               = 'Показує кількість статтей у підкатегоріях. Увага! Данна опція збільшує навантаження на сервер при великій кількості статтей!';
$_['help_blog_menu']       	           = 'Додати у верхнє горизвінтальне меню посилання на Блог.';
$_['help_review']       	           = 'Включення/Вимкнення відгуків';
$_['help_review_guest']       	       = 'Дозволити гостям залишати відгуки.';
$_['help_review_mail']                 = 'Відправити повідомлення на E-Mail про новий відгук.';

// Error
$_['error_warning']                    = 'Уважно перевірте форму на помилки!';
$_['error_permission']                 = 'У вас недостатньо прав для внесення змін!';
$_['error_limit']       	           = 'Вкажіть кількість!';
$_['error_image_article']              = 'Необхідно вказати розмір зображення у списку статтей!';
$_['error_image_category']             = 'Необхідно вказати розмір зображення в описі категорії блогу!';
$_['error_image_related']              = 'Необхідно вказати розмір зображення аналогічних статтей, товарів!';