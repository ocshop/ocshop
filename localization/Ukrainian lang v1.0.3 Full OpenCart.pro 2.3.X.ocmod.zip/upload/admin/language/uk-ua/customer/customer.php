<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']         = 'Покупці';

// Text
$_['text_success']          = 'Налаштування успішно змінені!';
$_['text_list']             = 'Список покупців';
$_['text_add']              = 'Додати';
$_['text_edit']             = 'Редагування';
$_['text_default']          = 'За замовчуванням';
$_['text_balance']          = 'Баланс';

// Column
$_['column_name']           = 'Ім\'я покупця';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Група покупців';
$_['column_status']         = 'Статус';
$_['column_date_added']     = 'Дата додавання';
$_['column_comment']        = 'Коментар';
$_['column_description']    = 'Опис';
$_['column_amount']         = 'Разом';
$_['column_points']         = 'Бонусні бали';
$_['column_ip']             = 'IP';
$_['column_total']          = 'Загальна сума';
$_['column_action']         = 'Дія';

// Entry
$_['entry_customer_group']  = 'Група покупців';
$_['entry_firstname']       = 'Ім\'я';
$_['entry_lastname']        = 'Прізвище';
$_['entry_email']           = 'E-Mail';
$_['entry_telephone']       = 'Телефон';
$_['entry_fax']             = 'Факс';
$_['entry_newsletter']      = 'Розсилка';
$_['entry_status']          = 'Статус';
$_['entry_approved']        = 'Схвалити';
$_['entry_safe']            = 'Безпечний';
$_['entry_password']        = 'Пароль';
$_['entry_confirm']         = 'Підтвердити';
$_['entry_company']         = 'Компанія';
$_['entry_address_1']       = 'Адреса 1';
$_['entry_address_2']       = 'Адреса 2';
$_['entry_city']            = 'Місто';
$_['entry_postcode']        = 'Індекс';
$_['entry_country']         = 'Країна';
$_['entry_zone']            = 'Регіон / область';
$_['entry_default']         = 'Основна адреса';
$_['entry_comment']         = 'Коментар';
$_['entry_description']     = 'Опис';
$_['entry_amount']          = 'Разом';
$_['entry_points']          = 'Бонусні бали';
$_['entry_name']            = 'Ім\'я покупця';
$_['entry_ip']              = 'IP';
$_['entry_date_added']      = 'Дата додавання';

// Help
$_['help_safe']             = 'Установіть значення Справжній, у тому випадку, якщо він був помилково був визначений системою з боротьби з шахрайством';
$_['help_points']           = 'Використовуйте мінус для віднімання балів, наприклад, -100';

// Error
$_['error_warning']         = 'Уважно перевірте форму на помилки!';
$_['error_permission']      = 'У вас недостатньо прав для внесення змін!';
$_['error_exists']          = 'Такий E-Mail вже зареєстрований!';
$_['error_firstname']       = 'Ім\'я повинно містити від 1 до 32 символів!';
$_['error_lastname']        = 'Прізвище повинно містити від 1 до 32 символів!';
$_['error_email']           = 'E-Mail адреса введена невірно!';
$_['error_telephone']       = 'Номер телефона повинен містити від 3 до 32 символів!';
$_['error_password']        = 'Пароль повинен містити від 4 до 20 символів!';
$_['error_confirm']         = 'Паролі не співпадають!';
$_['error_address_1']       = 'Адреса повинна містити від 3 до 128 символів!';
$_['error_city']            = 'Назва міста повинна містити від 2 до 128 символів!';
$_['error_postcode']        = 'Індекс повинен містити від 2 до 10 символів!';
$_['error_country']         = 'Будь ласка, вкажіть країну!';
$_['error_zone']            = 'Будь ласка, вкажіть регіон / область!';
$_['error_custom_field']    = '%s необхідний!';