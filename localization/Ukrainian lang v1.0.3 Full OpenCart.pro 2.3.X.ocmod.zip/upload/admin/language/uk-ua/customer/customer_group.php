<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Групи покупців';

// Text
$_['text_success']      = 'Налаштування успішно змінені!';
$_['text_list']         = 'Список груп покупців';
$_['text_add']          = 'Додати';
$_['text_edit']         = 'Редагування';

// Column
$_['column_name']       = 'Назва группы покупців';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action']     = 'Дія';

// Entry
$_['entry_name']        = 'Назва групи покупців';
$_['entry_description'] = 'Опис';
$_['entry_approval']    = 'Підтвердження нових покупців';
$_['entry_sort_order']  = 'Порядок сортування';

// Help
$_['help_approval']     = 'Покупці повинні бути активовані адміністратором, перш ніж вони зможуть здійснити покупки і використовувати всі переваги зареєстрованих користувачів';

// Error
$_['error_permission']   = 'У вас недостатньо прав для внесення змін!';
$_['error_name']         = 'Назва повинна містити від 3 до 32 символів!';
$_['error_default']      = 'Цю групу покупців неможливо видалити, оскільки вона назначена для основного магазину!';
$_['error_store']        = 'Цю групу покупців неможливо видалити, оскільки вона використовується в %s магазинах!';
$_['error_customer']     = 'Цю групу покупців неможливо видалити, оскільки в неї входить %s покупців!';