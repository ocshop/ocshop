<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']         = 'Налаштовувані поля';

// Text
$_['text_success']          = 'Налаштування успішно змінені!';
$_['text_list']             = 'Список налаштованих полей';
$_['text_add']              = 'Додати';
$_['text_edit']             = 'Редагування';
$_['text_choose']           = 'Вибір';
$_['text_select']           = 'Список';
$_['text_radio']            = 'Перемикач';
$_['text_checkbox']         = 'Прапорець';
$_['text_input']            = 'Поле ввода';
$_['text_text']             = 'Текст';
$_['text_textarea']         = 'Текстова область';
$_['text_file']             = 'Файл';
$_['text_date']             = 'Дата';
$_['text_datetime']         = 'Дата і час';
$_['text_time']             = 'Час';
$_['text_account']          = 'Акаунт';
$_['text_address']          = 'Адреса';

// Column
$_['column_name']           = 'Назва налаштовуваного поля';
$_['column_location']       = 'Розташування';
$_['column_type']           = 'Тип';
$_['column_sort_order']     = 'Порядок сортування';
$_['column_action']         = 'Дія';

// Entry
$_['entry_name']            = 'Назва налаштовуваного поля';
$_['entry_location']        = 'Розташування';
$_['entry_type']            = 'Тип';
$_['entry_value']           = 'Значення';
$_['entry_custom_value']    = 'Значення поля';
$_['entry_customer_group']  = 'Група покупців';
$_['entry_required']        = 'Необхідно';
$_['entry_status']          = 'Статус';
$_['entry_sort_order']      = 'Порядок сортування';

// Help
$_['help_sort_order']       = 'Використовуйте мінус, щоб задати порядок сортуваннях вище.';

// Error
$_['error_permission']      = 'У вас недостатньо прав для внесення змін!';
$_['error_name']            = 'Назва повинна містити від 1 до 128 символів!';
$_['error_type']            = 'Укажіть значення!';
$_['error_custom_value']    = 'Значення повинно містити від 3 до 128 символів!';