<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    = 'Бекап / Відновлення';

// Text
$_['text_backup']      = 'Архівувати базу даних';
$_['text_success']     = 'База даних імпортована!';
$_['text_list']        = 'Список завантажень';

// Entry
$_['entry_restore']    = 'Відновити базу даних';
$_['entry_export']     = 'Експорт';
$_['entry_import']     = 'Імпорт';
$_['entry_backup']     = 'Бекап';

// Error
$_['error_permission'] = 'У вас недостатньо прав для внесення змін!';
$_['error_backup']     = 'Потрібно вибрати хоча б одну таблицю!';
$_['error_empty']      = 'Завантажений файл порожній!';