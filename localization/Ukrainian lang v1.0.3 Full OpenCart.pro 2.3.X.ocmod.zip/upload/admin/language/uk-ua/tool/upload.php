<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Завантаження';

// Text
$_['text_success']      = 'Налаштування успішно змінені!';
$_['text_list']         = 'Список завантажень';

// Column
$_['column_name']       = 'Назва';
$_['column_filename']   = 'Ім\'я файлу';
$_['column_date_added'] = 'Дата додавання';
$_['column_action']     = 'Дія';

// Entry
$_['entry_name']        = 'Назва';
$_['entry_filename']    = 'Ім\'я файлу';
$_['entry_date_added'] 	= 'Дата додавання';

// Error
$_['error_permission']  = 'У вас недостатньо прав для внесення змін!';