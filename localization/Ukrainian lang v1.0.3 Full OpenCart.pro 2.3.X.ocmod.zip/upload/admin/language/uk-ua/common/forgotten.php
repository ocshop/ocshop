<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// header
$_['heading_title']   = 'Забули пароль?';

// Text
$_['text_forgotten']  = 'Забули пароль?';
$_['text_your_email'] = 'Ваш E-Mail';
$_['text_email']      = 'Введіть адресу електронної пошти вашого облікового запису. Натисніть кнопку Продовжити, щоб отримати посилання на скидання паролю електронною поштою.';
$_['text_success']    = 'Посилання підтверждення скидання паролю була відправлена на вашу електронну пошту.';

// Entry
$_['entry_email']     = 'E-Mail адреса';
$_['entry_password']  = 'Новий пароль';
$_['entry_confirm']   = 'Підтвердіть пароль';

// Error
$_['error_email']     = 'E-Mail адреса не знайдена, перевірте і спробуйте щє раз!';
$_['error_password']  = 'Пароль повинен містити від 3 до 20 символів!';
$_['error_confirm']   = 'Паролі не співпадають!';