<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// header
$_['heading_title']  = 'Скидання паролю';

// Text
$_['text_reset']     = 'Скидання паролю!';
$_['text_password']  = 'Введіть новий пароль!';
$_['text_success']   = 'Ваш пароль успішно змінен!';

// Entry
$_['entry_password'] = 'Новий пароль';
$_['entry_confirm']  = 'Підтвердіть пароль';

// Error
$_['error_password'] = 'Пароль повинен містити від 3 до 20 символів!';
$_['error_confirm']  = 'Паролі не співпадают!';