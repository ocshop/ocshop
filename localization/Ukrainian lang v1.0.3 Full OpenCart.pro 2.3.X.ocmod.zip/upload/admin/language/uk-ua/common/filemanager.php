<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    = 'Менеджер зображень';

// Text
$_['text_uploaded']    = 'Файл завантажен!';
$_['text_directory']   = 'Директорія створена!';
$_['text_delete']      = 'Файл або директорія видалена!';

// Entry
$_['entry_search']     = 'Пошук..';
$_['entry_folder']     = 'Нова папка';

// Error
$_['error_permission'] = 'Доступ Заборонено!';
$_['error_filename']   = 'Назва файлу повинна містити від 3 до 255 символів!';
$_['error_folder']     = 'Назва директорії повинна містити від 3 до 255 символів!';
$_['error_exists']     = 'Файл або директорія з такою назвою вже існує!';
$_['error_directory']  = 'Выберіть директорію!';
$_['error_filetype']   = 'Некоректний тип файлу!';
$_['error_upload']     = 'Файл не може бути завантажен з невідомої причини!';
$_['error_delete']     = 'Неможливо видалити директорію!';