<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_footer'] 	= '<a href="http://opencart.pro/">OPENCART.PRO</a> &copy; 2009-' . date('Y') . ' Усі права захищені. <br /><a href="http://forum.opencart.pro">Форум Підтримки</a>';
$_['text_version'] 	= 'Версія %s';