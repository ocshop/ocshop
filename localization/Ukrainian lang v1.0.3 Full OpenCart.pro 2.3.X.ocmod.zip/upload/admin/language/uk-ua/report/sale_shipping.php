<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Звіт з доставок';

// Text
$_['text_list']         = 'Список доставок';
$_['text_year']         = 'Роки';
$_['text_month']        = 'Місяці';
$_['text_week']         = 'Тижні';
$_['text_day']          = 'Дні';
$_['text_all_status']   = 'Усі статуси';

// Column
$_['column_date_start'] = 'Дата початку';
$_['column_date_end']   = 'Дата закінчення';
$_['column_title']      = 'Назва доставки';
$_['column_orders']     = 'К-ть замовлень';
$_['column_total']      = 'Всього';

// Entry
$_['entry_date_start']  = 'Дата початку';
$_['entry_date_end']    = 'Дата закінчення';
$_['entry_group']       = 'Сортувати за';
$_['entry_status']      = 'Статус';