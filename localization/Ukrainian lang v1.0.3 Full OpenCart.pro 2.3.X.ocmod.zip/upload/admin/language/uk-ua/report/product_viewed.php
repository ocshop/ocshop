<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    = 'Звіт з переглянутих товарів';

// Text
$_['text_list']        = 'Список переглянутих товарів';
$_['text_success']     = 'Список переглянутих товарів очищений!';

// Column
$_['column_name']      = 'Назва товару';
$_['column_model']     = 'Код товару';
$_['column_viewed']    = 'Переглядів';
$_['column_percent']   = 'Відсоток';

// Error
$_['error_permission'] = 'У вас недостатньо прав для внесення змін!';