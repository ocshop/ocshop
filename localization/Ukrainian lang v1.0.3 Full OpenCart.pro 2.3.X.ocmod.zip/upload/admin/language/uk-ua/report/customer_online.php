<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Покупці онлайн';

// Text
$_['text_list']         = 'Список онлайн покупців';
$_['text_guest']        = 'Гість';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Покупець';
$_['column_url']        = 'Остання відвідана сторінка';
$_['column_referer']    = 'Звідки приийшов';
$_['column_date_added'] = 'Останній клік';
$_['column_action']     = 'Дія';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Покупець';