<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Звіт по комісіям партнерів';

// Text
$_['text_list']         = 'Список партнерської комісії';

// Column
$_['column_affiliate']  = 'Ім\'я партнера';
$_['column_email']      = 'E-Mail';
$_['column_status']     = 'Статус';
$_['column_commission'] = 'Комісія';
$_['column_orders']     = 'К-ть замовлень';
$_['column_total']      = 'Всього';
$_['column_action']     = 'Дія';

// Entry
$_['entry_date_start']  = 'Дата початку';
$_['entry_date_end']    = 'Дата закінчення';