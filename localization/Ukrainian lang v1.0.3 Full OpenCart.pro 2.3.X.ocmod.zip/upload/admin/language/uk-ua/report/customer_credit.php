<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']         = 'Звіт по кредиту покупців';

// Column
$_['text_list']             = 'Список кредитів покупців';
$_['column_customer']       = 'Ім\'я покупця';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Група покупців';
$_['column_status']         = 'Статус';
$_['column_total']          = 'Всього';
$_['column_action']         = 'Дія';

// Entry
$_['entry_date_start']      = 'Дата початку';
$_['entry_date_end']        = 'Дата закінчення';
$_['entry_customer']		= 'Ім\'я покупця';