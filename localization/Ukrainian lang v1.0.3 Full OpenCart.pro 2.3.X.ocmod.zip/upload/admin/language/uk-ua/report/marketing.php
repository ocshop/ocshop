<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    	= 'Звіт з маркетингу';

// Text
$_['text_list']         = 'Списки відстеження';
$_['text_all_status']   = 'Усі статуси';

// Column
$_['column_campaign']  	= 'Назва компанії';
$_['column_code']      	= 'Код';
$_['column_clicks']    	= 'Кліки';
$_['column_orders']    	= 'К-ть замовлень';
$_['column_total']     	= 'Всього';

// Entry
$_['entry_date_start'] 	= 'Дата початку';
$_['entry_date_end']   	= 'Дата закінчення';
$_['entry_status']     	= 'Статус замовлення';