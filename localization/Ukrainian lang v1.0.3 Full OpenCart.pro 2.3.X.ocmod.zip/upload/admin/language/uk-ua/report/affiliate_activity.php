<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Звіт партнерської активності';

// Text
$_['text_list']         = 'Список партнерської активності';
$_['text_edit']         = '<a href="affiliate_id=%d">%s</a> - оновлена інформація акаунта.';
$_['text_forgotten']    = '<a href="affiliate_id=%d">%s</a> - запит нового паролю.';
$_['text_login']        = '<a href="affiliate_id=%d">%s</a> - выконано вхід.';
$_['text_password']     = '<a href="affiliate_id=%d">%s</a> - оновлено пароль.';
$_['text_payment']      = '<a href="affiliate_id=%d">%s</a> - оновлені платіжні реквізити.';
$_['text_register']     = '<a href="affiliate_id=%d">%s</a> - зареєстровано нового партнера.';

// Column
$_['column_affiliate']  = 'Партнер';
$_['column_comment']    = 'Коментар';
$_['column_ip']         = 'IP';
$_['column_date_added'] = 'Дата додавання';

// Entry
$_['entry_affiliate']   = 'Партнер';
$_['entry_ip']          = 'IP';
$_['entry_date_start']  = 'Дата початку';
$_['entry_date_end']    = 'Дата закінчення';