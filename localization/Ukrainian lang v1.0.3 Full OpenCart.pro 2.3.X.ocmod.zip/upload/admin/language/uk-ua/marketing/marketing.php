<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Маркетингове відстеження';

// Text
$_['text_success']      = 'Налаштування успішно змінені!';
$_['text_list']         = 'Список маркетингових відстежень';
$_['text_add']          = 'Додати';
$_['text_edit']         = 'Редагування';

// Column
$_['column_name']       = 'Назва кампанії';
$_['column_code']       = 'Код';
$_['column_clicks']     = 'Кліки';
$_['column_orders']     = 'Замовлення';
$_['column_date_added'] = 'Дата додавання';
$_['column_action']     = 'Дія';

// Entry
$_['entry_name']        = 'Назва кампанії';
$_['entry_description'] = 'Опис кампанії';
$_['entry_code']        = 'Код відстеження';
$_['entry_example']     = 'Приклади';
$_['entry_date_added']  = 'Дата додавання';

// Help
$_['help_code']         = 'Код відстеження, який використовується для відстеження рекламний кампаній.';
$_['help_example']      = 'Так як система може відстежувати партнерів, треба додати код відстеження в кінець URL-адреси посилання на ваш сайт.';

// Error
$_['error_permission']  = 'У вас недостатньо прав для внесення змін!';
$_['error_name']        = 'Назва повинна містити від 1 до 32 символів!';
$_['error_code']        = 'Необхідно вказати код відстеження!';