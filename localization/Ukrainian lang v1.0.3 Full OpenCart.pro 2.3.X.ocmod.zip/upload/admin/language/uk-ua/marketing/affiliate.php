<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']             = 'Партнерська програма';

// Text
$_['text_success']              = 'Налаштування успішно змінені!';
$_['text_approved']             = 'Ви схвалили %s акаунтів!';
$_['text_list']                 = 'Список партнерських програм';
$_['text_add']                  = 'Додати';
$_['text_edit']                 = 'Редагування';
$_['text_affiliate_detail']     = 'Деталі партнера';
$_['text_affiliate_address']    = 'Адреса партнера';
$_['text_balance']              = 'Баланс';
$_['text_cheque']               = 'Чек';
$_['text_paypal']               = 'PayPal';
$_['text_bank']                 = 'Банківський переказ';

// Column
$_['column_name']               = 'Ім\'я партнера';
$_['column_email']              = 'E-Mail';
$_['column_code']               = 'Код відстеження';
$_['column_balance']            = 'Баланс';
$_['column_status']             = 'Статус';
$_['column_approved']           = 'Схвалити';
$_['column_date_added']         = 'Дата додавання';
$_['column_description']        = 'Опис';
$_['column_amount']             = 'Всього';
$_['column_action']             = 'Дія';

// Entry
$_['entry_firstname']           = 'Ім\'я';
$_['entry_lastname']            = 'Прізвище';
$_['entry_email']               = 'E-Mail';
$_['entry_telephone']           = 'Телефон';
$_['entry_fax']                 = 'Факс';
$_['entry_status']              = 'Статус';
$_['entry_password']            = 'Пароль';
$_['entry_confirm']             = 'Підтвердити пароль';
$_['entry_company']             = 'Компанія';
$_['entry_website']             = 'Веб-сайт';
$_['entry_address_1']           = 'Адреса 1';
$_['entry_address_2']           = 'Адреса 2';
$_['entry_city']                = 'Міста';
$_['entry_postcode']            = 'Індекс';
$_['entry_country']             = 'Країна';
$_['entry_zone']                = 'Регіон / область';
$_['entry_code']                = 'Код відстеження';
$_['entry_commission']          = 'Нагорода (%)';
$_['entry_tax']                 = 'Податковий код (ИНП)';
$_['entry_payment']             = 'Спосіб оплати';
$_['entry_cheque']              = 'Чек, Ім\'я отримувача платежу';
$_['entry_paypal']              = 'PayPal Email акаунт';
$_['entry_bank_name']           = 'Назва банку';
$_['entry_bank_branch_number']  = 'ABA/BSB номер (номер відділення)';
$_['entry_bank_swift_code']     = 'SWIFT код';
$_['entry_bank_account_name']   = 'Назва рахунку';
$_['entry_bank_account_number'] = 'Номер рахунку';
$_['entry_amount']              = 'Всього';
$_['entry_description']         = 'Опис';
$_['entry_name']                = 'Ім\'я партнера';
$_['entry_approved']            = 'Схвалити';
$_['entry_date_added']          = 'Дата додавання';

// Help
$_['help_code']                 = 'Цей код використовується для відстеження рефералів.';
$_['help_commission']           = 'Відсоток, який партнер отримує за кожне замовлення.';

// Error
$_['error_warning']             = 'Уважно перевірте форму на помилки!';
$_['error_permission']          = 'У вас недостатньо прав для внесення змін!';
$_['error_exists']              = 'Такий E-Mail вже зареєстрований!';
$_['error_firstname']           = 'Ім\'я повинна містити від 1 до 32 символів!';
$_['error_lastname']            = 'Прізвище повинно містити від 1 до 32 символів!';
$_['error_email']               = 'E-Mail адреса введена невірно!';
$_['error_cheque']              = 'Необхідно вказати Ім\'я отримувача чеку!';
$_['error_paypal']              = 'Невірна адреса електронної пошти PayPal!';
$_['error_bank_account_name']   = 'Необхідно вказати назву облікового запису!';
$_['error_bank_account_number'] = 'Необхідно вказати номер рахунку!';
$_['error_telephone']           = 'Номер телефону повинен містити від 3 до 32 символів!';
$_['error_password']            = 'Пароль повинен містити від 4 до 20 символів!';
$_['error_confirm']             = 'Паролі не співпадають!';
$_['error_address_1']           = 'Адреса повинна містити від 3 до 128 символів!';
$_['error_city']                = 'Назва міста повинна містити від 2 до 128 символів!';
$_['error_postcode']            = 'Індекс повинен містити від 2 до 10 символів!';
$_['error_country']             = 'Будь ласка, вкажіть країну!';
$_['error_zone']                = 'Будь ласка, вкажіть регіон / область!';
$_['error_code']                = 'Необхідно вказати реферальний код!';