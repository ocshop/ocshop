<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']                        = 'Профабо періодичності';

// Text
$_['text_success']                         = 'Налаштування успішно змінені!';
$_['text_list']                            = 'Список профілей періодичності';
$_['text_add']                             = 'Додати';
$_['text_edit']                            = 'Редагування';
$_['text_payment_profiles']                = 'Профабо періодичності';
$_['text_status_active']                   = 'Увімкнен';
$_['text_status_inactive']                 = 'Вимкнен';
$_['text_status_cancelled']                = 'Скасовано';
$_['text_status_suspended']                = 'Заморожен';
$_['text_status_expired']                  = 'Закінчився';
$_['text_status_pending']                  = 'Очікує';
$_['text_transactions']                    = 'Операції';
$_['text_cancel_confirm']                  = 'Видалення профілю неможливо відмінити! Ви впевнені?';
$_['text_transaction_date_added']          = 'Дата додавання';
$_['text_transaction_payment'] 			   = 'Платіж';
$_['text_transaction_outstanding_payment'] = 'Непоступивший платіж';
$_['text_transaction_skipped']             = 'Платіж пропущений';
$_['text_transaction_failed']              = 'Проблема з оплатою';
$_['text_transaction_cancelled']           = 'Скасовано';
$_['text_transaction_suspended']           = 'Заморожений';
$_['text_transaction_suspended_failed']    = 'Заморожений із-за невдалого платежа';
$_['text_transaction_outstanding_failed']  = 'Платіж не пройшов';
$_['text_transaction_expired']             = 'Закінчився';

// Entry
$_['entry_cancel_payment']                 = 'Відміна оплати';
$_['entry_order_recurring']                = '№';
$_['entry_order_id']                       = '№ замовлення';
$_['entry_reference']                      = 'Спосіб оплати';
$_['entry_customer']                       = 'Покупець';
$_['entry_date_added']                     = 'Дата додавання';
$_['entry_status']                         = 'Статус';
$_['entry_type']                           = 'Тип';
$_['entry_action']                         = 'Дія';
$_['entry_email']                          = 'E-Mail';
$_['entry_description']                    = 'Опис профілю періодичного замовлення';
$_['entry_product']                        = 'Товар';
$_['entry_quantity']                       = 'Кількість';
$_['entry_amount']                         = 'Всього';
$_['entry_recurring']                      = 'Профіль періодичності';
$_['entry_payment_method']                 = 'Спосіб оплати';

// Error / Success
$_['error_not_cancelled']                  = 'Помилка: %s';
$_['error_not_found']                      = 'Неможливо зачинити регулярний профіль!';
$_['text_cancelled']                       = 'Регулярній платіж був зачинений';
