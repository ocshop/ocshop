<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']           = 'Країни';

// Text
$_['text_success']            = 'Налаштування успішно змінені!';
$_['text_list']               = 'Список країн';
$_['text_add']                = 'Додати';
$_['text_edit']               = 'Редагування';

// Column
$_['column_name']             = 'Назва країни';
$_['column_iso_code_2']       = 'Код ISO (2)';
$_['column_iso_code_3']       = 'Код ISO (3)';
$_['column_action']           = 'Дія';

// Entry
$_['entry_name']              = 'Назва країни';
$_['entry_iso_code_2']        = 'Код ISO (2)';
$_['entry_iso_code_3']        = 'Код ISO (3)';
$_['entry_address_format']    = 'Формат адреси';
$_['entry_postcode_required'] = 'Індекс обов\'язковий';
$_['entry_status']            = 'Статус';

// Help
$_['help_address_format']     = 'Им\'я = {firstname}<br />Прізвище = {lastname}<br />Компания = {company}<br />Адреса 1 = {address_1}<br />Адреса 2 = {address_2}<br />Город = {city}<br />Індекс = {postcode}<br />Регіон = {zone}<br />Код регіона = {zone_code}<br />Країна = {country}';

// Error
$_['error_permission']        = 'У вас недостатньо прав для внесення змін!';
$_['error_name']              = 'Назва повинна містити від 3 до 128 символів!';
$_['error_default']           = 'Цю країну неможливо видалити, оскільки вона використовується як країна за замовчуванням для магазину!';
$_['error_store']             = 'Цю країну неможливо видалити, оскільки вона використовується в %s магазинах!';
$_['error_address']           = 'Цю країну неможливо видалити, оскільки вона використовується в %s адресах!';
$_['error_affiliate']         = 'Цю країну неможливо видалити, оскільки вона використовується %s партнерами!';
$_['error_zone']              = 'Цю країну неможливо видалити, оскільки вона використовується в %s зонах!';
$_['error_zone_to_geo_zone']  = 'Цю країну неможливо видалити, оскільки вона використовується в %s географічних зонах!';