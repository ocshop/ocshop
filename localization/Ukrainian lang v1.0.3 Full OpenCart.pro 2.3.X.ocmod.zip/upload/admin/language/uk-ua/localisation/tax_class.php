<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Податкові класи';

// Text
$_['text_success']      = 'Налаштування успішно змінені!';
$_['text_list']         = 'Список податкових класів';
$_['text_add']          = 'Додати';
$_['text_edit']         = 'Редагування';
$_['text_shipping']     = 'Адреса доставки';
$_['text_payment']      = 'Платіжна адреса';
$_['text_store']        = 'Адреса магазину';

// Column
$_['column_title']      = 'Назва податкового класу';
$_['column_action']     = 'Дія';

// Entry
$_['entry_title']       = 'Назва податкового класу';
$_['entry_description'] = 'Опис';
$_['entry_rate']        = 'Ставка податку';
$_['entry_based']       = 'Заснована на';
$_['entry_geo_zone']    = 'Географічна зона';
$_['entry_priority']    = 'Пріорітет';

// Error
$_['error_permission']  = 'У вас недостатньо прав для внесення змін!';
$_['error_title']       = 'Назва повинна містити від 3 до 32 символів!';
$_['error_description'] = 'Опис повинен містити від 3 до 255 символів!';
$_['error_product']     = 'Цей податковий клас неможливо видалити, оскільки він використовується в %s товарах!';