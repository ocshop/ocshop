<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']      = 'Географічні зони';

// Text
$_['text_success']       = 'Налаштування успішно змінені!';
$_['text_list']          = 'Список географічних звон';
$_['text_add']           = 'Додати';
$_['text_edit']          = 'Редагування';

// Column
$_['column_name']        = 'Назва географічної зони';
$_['column_description'] = 'Опис';
$_['column_action']      = 'Дія';

// Entry
$_['entry_name']         = 'Назва географічної зони';
$_['entry_description']  = 'Опис';
$_['entry_country']      = 'Країна';
$_['entry_zone']         = 'Регіон / область';

// Error
$_['error_permission']   = 'У вас недостатньо прав для внесення змін!';
$_['error_name']         = 'Назва повинна містити від 3 до 32 символів!';
$_['error_description']  = 'Опис повинен містити від 3 до 255 символів!';
$_['error_tax_rate']     = 'Цю географічну зону неможливо видалити, оскільки вона використовується в одній або декількох податкових ставках!';