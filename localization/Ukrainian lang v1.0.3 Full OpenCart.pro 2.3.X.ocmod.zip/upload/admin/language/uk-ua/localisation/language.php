<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Мови';

// Text
$_['text_success']      = 'Налаштування успішно змінені!';
$_['text_list']         = 'Список мов';
$_['text_add']          = 'Додати';
$_['text_edit']         = 'Редагування';

// Column
$_['column_name']       = 'Назва мови';
$_['column_code']       = 'Код';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action']     = 'Дія';

// Entry
$_['entry_name']        = 'Назва мови';
$_['entry_code']        = 'Код';
$_['entry_locale']      = 'Кодування';
$_['entry_image']       = 'Зображення';
$_['entry_directory']   = 'Директорія';
$_['entry_status']      = 'Статус';
$_['entry_sort_order']  = 'Порядок сортування';

// Help
$_['help_code']         = 'Наприклад: ru. Не змінювати, якщо мова установлена за замовчуванням.';
$_['help_locale']       = 'Наприклад: ru_RU.UTF-8,ru_RU,ru_RU,russian';
$_['help_image']        = 'Наприклад ru.png';
$_['help_directory']    = 'Назва директорії з перекладом (з урахуванням регістру)';
$_['help_status']       = 'Показувати/Приховувати у перемикачі мов вітрини магазину';

// Error
$_['error_permission']  = 'У вас недостатньо прав для внесення змін!';
$_['error_name']        = 'Назва повинна містити від 3 до 32 символів!';
$_['error_code']        = 'Код мови повинен містити від 2 символів!';
$_['error_locale']      = 'Необхідна мова!';
$_['error_image']       = 'Назва зображення повинна містити від 3 до 64 символів!';
$_['error_directory']   = 'Необхідно вказати каталог!';
$_['error_default']     = 'Цю мова неможливо видалити, оскільки вона використовується за замовчуванням!';
$_['error_admin']       = 'Цю мова неможливо видалити, оскільки вона використовується як мова Администратора';
$_['error_store']       = 'Цю мова неможливо видалити, оскільки вона використовується в %s магазинах!';
$_['error_order']       = 'Цю мова неможливо видалити, оскільки вона використовується в %s замовленнях!';