<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Користувачі';

// Text
$_['text_success']      = 'Налаштування успішно змінені!';
$_['text_list']         = 'Список користувачів';
$_['text_add']          = 'Додати';
$_['text_edit']         = 'Редагування';

// Column
$_['column_username']   = 'Логін';
$_['column_status']     = 'Статус';
$_['column_date_added'] = 'Дата додавання';
$_['column_action']     = 'Дія';

// Entry
$_['entry_username']   	= 'Логін';
$_['entry_user_group'] 	= 'Група користувачів';
$_['entry_password']   	= 'Пароль';
$_['entry_confirm']    	= 'Підтвердити';
$_['entry_firstname']  	= 'Ім\'я';
$_['entry_lastname']   	= 'Прізвище';
$_['entry_email']      	= 'E-Mail';
$_['entry_image']      	= 'Зображення';
$_['entry_status']     	= 'Статус';

// Error
$_['error_permission'] 	= 'У вас недостатньо прав для внесення змін!';
$_['error_account']    	= 'Ви не можете видалити свій власний акаунт!';
$_['error_exists']     	= 'Ім\'я користувача вже використовується!';
$_['error_username']   	= 'Логін повинен містити від 4 до 20 символів!';
$_['error_password']   	= 'Пароль повинен містити від 4 до 20 символів!';
$_['error_confirm']    	= 'Паролі не співпадають!';
$_['error_firstname']  	= 'Ім\'я повинно містити від 1 до 32 символів!';
$_['error_lastname']   	= 'Прізвище повинно містити від 1 до 32 символів!';