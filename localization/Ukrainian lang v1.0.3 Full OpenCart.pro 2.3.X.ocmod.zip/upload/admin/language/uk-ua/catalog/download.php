<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Файли для скачування';

// Text
$_['text_success']      = 'Налаштування успішно змінені!';
$_['text_list']         = 'Список файлів для скачування';
$_['text_add']          = 'Додати';
$_['text_edit']         = 'Редагування';
$_['text_upload']       = 'Файл успішно завантажен!';

// Column
$_['column_name']       = 'Назва';
$_['column_date_added'] = 'Дата додавання';
$_['column_action']     = 'Дія';

// Entry
$_['entry_name']        = 'Назва';
$_['entry_filename']    = 'Ім\'я файлу';
$_['entry_mask']        = 'Маска';

// Help
$_['help_filename']     = 'Ви можете завантажити файл через кнопку вибору файлу або по FTP, помістивши його в папку "download" і ввівши інформацію нижче.';
$_['help_mask']         = 'Рекомендується, щоб  Ім\'я файлу і маска відрізнялися, це не дозволить отримати прямий доступ до файлу.';

// Error
$_['error_permission']  = 'У вас недостатньо прав для внесення змін!';
$_['error_name']        = 'Назва повинна містити від 3 до 64 символів!';
$_['error_upload']      = 'Необхідно завантажити файл!';
$_['error_filename']    = 'Назва файлу повинна містити від 3 до 128 символів!';
$_['error_exists']      = 'Файл не знайден!';
$_['error_mask']        = 'Маска повинна містити від 3 до 128 символів!';
$_['error_filetype']    = 'Неправильний тип файлу!';
$_['error_product']     = 'Це завантаження неможливо видалити, так як воно використовується у %s товарах!';