<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']          = 'Характеристики';

// Text
$_['text_success']           = 'Налаштування успішно змінені!';
$_['text_list']              = 'Список характеристик';
$_['text_add']               = 'Додати';
$_['text_edit']              = 'Редагування';

// Column
$_['column_name']            = 'Назва характеристики';
$_['column_attribute_group'] = 'Група характеристик';
$_['column_sort_order']      = 'Порядок сортування';
$_['column_action']          = 'Дія';

// Entry
$_['entry_name']            = 'Назва характеристики';
$_['entry_attribute_group'] = 'Група характеристик';
$_['entry_sort_order']      = 'Порядок сортування';

// Error
$_['error_permission']      = 'У вас недостатньо прав для внесення змін!';
$_['error_attribute_group'] = 'Вкажіть групу характеристик!';
$_['error_name']            = 'Назва повинна містити від  3 до 64 символів!';
$_['error_product']         = 'Цю характеристику неможливо видалити так як ввона використовується в  %s товарах!';