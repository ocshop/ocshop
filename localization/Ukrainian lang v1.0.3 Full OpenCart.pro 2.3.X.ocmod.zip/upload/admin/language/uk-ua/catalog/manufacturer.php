<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']      	 = 'Виробнинки';

// Text
$_['text_success']       	 = 'Налаштування успішно змінені!';
$_['text_list']          	 = 'Список виробників';
$_['text_add']           	 = 'Додати';
$_['text_edit']          	 = 'Редагування';
$_['text_default']       	 = 'За замовчуванням';
$_['text_percent']       	 = 'Відсоток';
$_['text_amount']        	 = 'Фіксована сума';

// Column
$_['column_name']        	 = 'Назва виробника';
$_['column_sort_order']  	 = 'Порядок сортування';
$_['column_noindex']         = 'Індексація';
$_['column_action']      	 = 'Дія';

// Entry
$_['entry_name']             = 'Назва виробника';
$_['entry_description']      = 'Опис Верх:';
$_['entry_description_bottom']  = 'Опис Низ:';
$_['entry_meta_title'] 	     = 'Мета-тег Title';
$_['entry_meta_h1'] 	     = 'HTML-тег H1';
$_['entry_meta_keyword'] 	 = 'Мета-тег Keywords';
$_['entry_meta_description'] = 'Мета-тег Description';
$_['entry_store']            = 'Магазини';
$_['entry_keyword']    	     = 'SEO URL';
$_['entry_image']    	     = 'Зображення';
$_['entry_sort_order']  	 = 'Порядок сортування';
$_['entry_noindex']          = 'Індексація';
$_['entry_layout']           = 'Змінити макет';
$_['tab_design']             = 'Дизайн';
$_['entry_type']        	 = 'Тип';
$_['entry_related_mn']       = 'Рекомендовані товари:';
$_['entry_related_article']  = 'Рекомендовані статті:';

// Help
$_['help_keyword']       	 = 'Повинна бути унікальною на всю систему, без пробілів и спецсимволів';
$_['help_noindex']           = 'Індексація у пошукових системах Google, Yandex, Bing та інших';

// Error
$_['error_warning']          = 'Уважно перевірте форму на помилки!';
$_['error_permission']   	 = 'У вас недостатньо прав для внесення змін!';
$_['error_name']         	 = 'Назва повинна містити від 2 до 64 символів!';
$_['error_product']      	 = 'Цього виробника неможливо видалити так як він використовується в %s товарах!';
$_['error_meta_title']   	 = 'Мета-тег Title повинен містити від 0 до 255 символів!';
$_['error_meta_h1']	     	 = 'HTML-тег H1 повинен містити від 0 до 255 символів!';
$_['error_keyword']      	 = 'SEO URL вже використовується!';