<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']          = 'Товары';

// Text
$_['text_success']           = 'Налаштування успішно змінені!';
$_['text_list']              = 'Список товарів';
$_['text_add']               = 'Додати';
$_['text_edit']              = 'Редагування';
$_['text_plus']              = '+';
$_['text_minus']             = '-';
$_['text_default']           = 'За замовчуванням';
$_['text_option']            = 'Опції';
$_['text_option_value']      = 'Значення опції';
$_['text_percent']           = 'Відсоток';
$_['text_amount']            = 'Фіксована сума';
$_['text_none_category']            	= ' --- Без категорії --- ';
$_['text_none_manufacturer']            = ' --- Без виробника --- ';

// Column
$_['column_name']            = 'Назва товару';
$_['column_category']        = 'Категория';
$_['column_manufacturer']    = 'Виробник';
$_['column_model']           = 'Код товару';
$_['column_image']           = 'Зображення';
$_['column_price']           = 'Ціна';
$_['column_quantity']        = 'Кількість';
$_['column_status']          = 'Статус';
$_['column_noindex']         = 'Індексація';
$_['column_action']          = 'Дія';

// Entry
$_['entry_name']             = 'Назва товару';
$_['entry_description']      = 'Опис';
$_['entry_description_mini'] = 'Короткий опис:';
$_['entry_meta_title'] 	     = 'Мета-тег Title';
$_['entry_meta_h1'] 	     = 'HTML-тег H1';
$_['entry_meta_keyword'] 	 = 'Мета-тег Keywords';
$_['entry_meta_description'] = 'Мета-тег Description';
$_['entry_keyword']          = 'SEO URL';
$_['entry_model']            = 'Код товару';
$_['entry_sku']              = 'SKU';
$_['entry_upc']              = 'UPC';
$_['entry_ean']              = 'EAN';
$_['entry_jan']              = 'JAN';
$_['entry_isbn']             = 'ISBN';
$_['entry_mpn']              = 'MPN';
$_['entry_location']         = 'Розташування';
$_['entry_shipping']         = 'Необхідна доставка';
$_['entry_manufacturer']     = 'Виробник';
$_['entry_store']            = 'Магазини';
$_['entry_date_available']   = 'Дата надходження';
$_['entry_quantity']         = 'Кількість';
$_['entry_minimum']          = 'Мінімальна кількість';
$_['entry_stock_status']     = 'Немає на складі';
$_['entry_price']            = 'Ціна';
$_['entry_tax_class']        = 'Клас податку';
$_['entry_points']           = 'Бонусні бали';
$_['entry_option_points']    = 'Бонусні бали';
$_['entry_subtract']         = 'Віднімати зі складу';
$_['entry_weight_class']     = 'Одиниця виміру ваги';
$_['entry_weight']           = 'Вага';
$_['entry_dimension']        = 'Розміри (Д х Ш х В)';
$_['entry_length_class']     = 'Одиниця виміру довжини';
$_['entry_length']           = 'Довжина';
$_['entry_width']            = 'Ширина';
$_['entry_height']           = 'Висота';
$_['entry_image']            = 'Зображення';
$_['entry_additional_image'] = 'Додаткові зображення';
$_['entry_customer_group']   = 'Група покупців';
$_['entry_date_start']       = 'Дата початку';
$_['entry_date_end']         = 'Дата закінчення';
$_['entry_priority']         = 'Пріорітет';
$_['entry_attribute']        = 'Характеристики';
$_['entry_attribute_group']  = 'Група характеристик';
$_['entry_text']             = 'Текст';
$_['entry_option']           = 'Опції';
$_['entry_option_value']     = 'Значення опції';
$_['entry_required']         = 'Необхідно';
$_['entry_status']           = 'Статус';
$_['entry_noindex']          = 'Індексація';
$_['entry_sort_order']       = 'Порядок сортування';
$_['entry_category']         = 'Категорії';
$_['entry_sub_category']     = 'Включаючи підкатегорії';
$_['entry_main_category']    = 'Головна категорія';
$_['entry_filter']           = 'Фільтри';
$_['entry_download']         = 'Файли для скачування';
$_['entry_related']          = 'Рекомендовані товари';
$_['entry_related_article']  = 'Рекомендуємо почитати';
$_['entry_tag']          	 = 'Теги товару';
$_['entry_reward']           = 'Бонусні бали';
$_['entry_layout']           = 'Змінити макет';
$_['entry_recurring']        = 'Профіль періодичності';
$_['entry_heading']     	 = 'Назва';
$_['entry_min']              = 'Від';
$_['entry_max']              = 'До';

// Help
$_['help_keyword']           = 'Повинна бути унікальною на всю систему, без пробілів и спецсимволів';
$_['help_sku']               = 'SKU - Код виробника';
$_['help_upc']               = 'Універсальний Код товару';
$_['help_ean']               = 'Європейский Код товару';
$_['help_jan']               = 'Японський Код товару';
$_['help_isbn']              = 'Міжнародний стандартний книжковий номер';
$_['help_mpn']               = 'Код Партії товару виробника';
$_['help_manufacturer']      = '(Автозаповнення)';
$_['help_minimum']           = 'Минімальна кількість заказу цього товару';
$_['help_stock_status']      = 'Статус, який показується, коли товару немає на складі (Кількість = 0)';
$_['help_points']            = 'Кількість балів для покупки товару. Поставте 0, щоб не використовувати бали.';
$_['help_category']          = '(Автозаповнення)';
$_['help_filter']            = '(Автозаповнення)';
$_['help_download']          = '(Автозаповнення)';
$_['help_related']           = '(Автозаповнення)';
$_['help_tag']          	 = 'розділяються комою';
$_['help_noindex']           = 'Індексація у пошукових системах Google, Yandex, Bing та інших';

//Stickers
$_['text_corner0']           = 'Верхній лівий';
$_['text_corner1']           = 'Верхній правий';
$_['text_corner2']           = 'Нижній лівий';
$_['text_corner3']           = 'Нижній правий';
$_['entry_sticker']          = 'Промо Стікери';
$_['text_benefits']          = 'Переваги';

// Error
$_['error_warning']          = 'Уважно перевірте форму на помилки!';
$_['error_permission']       = 'У вас недостатньо прав для внесення змін!';
$_['error_name']             = 'Назва повинна містити від 3 до 255 символів!';
$_['error_meta_title']       = 'Мета-тег Title повинен містити від 0 до 255 символів!';
$_['error_meta_h1'] 	     = 'HTML-тег H1 повинен містити від 0 до 255 символів!';
$_['error_model']            = 'Код Товара товара повинен містити від 3 до 64 символів!';
$_['error_keyword']          = 'SEO URL вже використовується!';
$_['error_tab']              = 'Необхідна назва таба!';