<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']          = 'Статті';

// Text
$_['text_success']           = 'Налаштування успішно змінені!';
$_['text_list']              = 'Список cтаттей';
$_['text_add']               = 'Додати';
$_['text_edit']              = 'Редагування';
$_['text_default']           = 'За замовчуванням';

// Column
$_['column_title']           = 'Назва Статті';
$_['column_sort_order']	     = 'Порядок сортування';
$_['column_noindex']         = 'Індексація';
$_['column_action']          = 'Дія';

// Entry
$_['entry_title']            = 'Назва Статті';
$_['entry_description']      = 'Опис';
$_['entry_store']            = 'Магазини';
$_['entry_meta_title'] 	     = 'Мета-тег Title';
$_['entry_meta_h1'] 	     = 'HTML-тег H1';
$_['entry_meta_keyword'] 	 = 'Мета-тег Keywords';
$_['entry_meta_description'] = 'Мета-тег Description';
$_['entry_keyword']          = 'SEO URL';
$_['entry_bottom']           = 'Відображати у футері';
$_['entry_status']           = 'Статус';
$_['entry_noindex']          = 'Індексація';
$_['entry_sort_order']       = 'Порядок сортування';
$_['entry_layout']           = 'Змінити макет';

// Help
$_['help_keyword']           = 'Повинна бути унікальною на всю систему, без пробілів і спецсимволів';
$_['help_bottom']            = 'Відображати в подвалі \ футері магазина';
$_['help_noindex']           = 'Індексація у пошукових системах Google, Yandex, Bing та інших';

// Error
$_['error_warning']          = 'Уважно перевірте форму на помилки!';
$_['error_permission']       = 'У вас недостатньо прав для внесення змін!';
$_['error_title']            = 'Назва повинна містити від 3 до 64 символів!';
$_['error_description']      = 'Опис повинен містити від 3 символів!';
$_['error_meta_title']       = 'Мета-тег Title повинен містити від 0 до 255 символів!';
$_['error_meta_h1']       	 = 'HTML-тег H1 повинен містити від 0 до 255 символів!';
$_['error_keyword']          = 'SEO URL вже використовується!';
$_['error_account']          = 'Цю сторінку неможливо видалити, так як вона використовується у Політиці безпеки за замовчуванням!';
$_['error_checkout']         = 'Цю сторінку неможливо видалити, так як вона використовується в Умовах згоди за замовчуванням!';
$_['error_affiliate']        = 'Цю сторінку неможливо видалити, так як вона використовується в Умовах партнерської програми!';
$_['error_return']           = 'Цю сторінку неможливо видалити, так як вона використовується в Умовах повернення товару!';
$_['error_store']            = 'Цю сторінку неможливо видалити, так як вона використовується в %s магазинах!';