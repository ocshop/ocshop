<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Фільтри';

// Text
$_['text_success']      = 'Налаштування успішно змінені!';
$_['text_list']         = 'Список фільтрів';
$_['text_add']          = 'Додати';
$_['text_edit']         = 'Редагування';

// Column
$_['column_group']      = 'Група Фільтрів';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action']     = 'Дія';

// Entry
$_['entry_group']       = 'Назва групи Фільтрів';
$_['entry_name']        = 'Назва Фільтра';
$_['entry_sort_order']  = 'Порядок сортування';

// Error
$_['error_permission']  = 'У вас недостатньо прав для внесення змін!';
$_['error_group']       = 'Назва Групи Фільтрів повинна містити від 1 до 64 символів!';
$_['error_name']        = 'Назва повинна містити від 1 до 64 символів!';