<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_subject']       = '%s - Повернення оновлено %s';
$_['text_return_id']     = '№ запита на повернення:';
$_['text_date_added']    = 'Дата повернення';
$_['text_return_status'] = 'Актуальний стан вашого повернення:';
$_['text_comment']       = 'Коментарі до вашого повернення:';
$_['text_footer']        = 'Якщо у Вас є будь-які питання, дайте відповідь на це повідомлення.';