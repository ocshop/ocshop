<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_approve_subject']      = '%s - Ваш партнерський акаунт активований!';
$_['text_approve_welcome']      = 'Ласкаво просимо в %s і дякуємо Вам за реєстрацію!!';
$_['text_approve_login']        = 'Ваш акаунт створений і Ви можете увійти, використовуючи свій E-mail і пароль, за поссиланням:';
$_['text_approve_services']     = 'У партнерському розділі Ви можете отримати реферальний код і реферальні посилання, відслідковувати комісіонні винагороди і редагувати параметри облікового запису.';
$_['text_approve_thanks']       = 'Дякуємо,';
$_['text_transaction_subject']  = '%s - Партнерські комісіонні';
$_['text_transaction_received'] = 'Ви отримали %s Комісіонних!';
$_['text_transaction_total']    = 'Ваш баланс комісіонних %s.';