<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_approve_subject']      = '%s - Ваш акаунт був активований!';
$_['text_approve_welcome']      = 'Ласкаво просимо в %s і дякуємо Вам за реєстрацію!!';
$_['text_approve_login']        = 'Ваш акаунт створений і Ви можете увійти, використовуючи свій E-mail і пароль, за поссиланням:';
$_['text_approve_services']     = 'Після реєстрації на сайті Ви зможете скористатися додатковими можливостями: Перегляд історії замовлень, друк рахунку, зміна інформації Вашого облікового запису та ін.';
$_['text_approve_thanks']       = 'Дякуємо,';
$_['text_transaction_subject']  = '%s - Рахунок акаунту';
$_['text_transaction_received'] = 'Ви отримали %s на свій рахунок в магазині';
$_['text_transaction_total']    = 'Загальна сума на Вашому акаунті: %s.' . "\n\n" . 'Ця сума буде автоматично витрачатися при наступних покупках.';
$_['text_reward_subject']       = '%s - Бонусні бали';
$_['text_reward_received']      = 'Ви отримали %s бонусних балів!';
$_['text_reward_total']         = 'Загальне число бонусних балів %s.';