<?php
// *	@copyright	OPENCART.PRO 2011 - 2017.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_subject']  = '%s - Зміна паролю';
$_['text_greeting'] = 'Новий пароль для %s.';
$_['text_change']   = 'Щоб змінити пароль натисніть на посилання:';
$_['text_ip']       = 'IP цього запиту: %s';