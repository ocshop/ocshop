<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Locale
$_['code']                  = 'uk';
$_['direction']             = 'ltr';
$_['date_format_short']     = 'd.m.Y';
$_['date_format_long']      = 'l, d F Y';
$_['time_format']           = 'H:i:s';
$_['datetime_format']       = 'd/m/Y H:i:s';
$_['decimal_point']         = '.';
$_['thousand_point']        = '';

// Text
$_['text_home']             = '<i class="fa fa-home"></i>';
$_['text_yes']              = 'Так';
$_['text_no']               = 'Ні';
$_['text_none']             = ' --- Не вибрано --- ';
$_['text_select']           = ' --- Оберіть --- ';
$_['text_all_zones']        = 'Усі зони';
$_['text_pagination']       = 'Показано з %d по %d із %d (всього %d сторінок)';
$_['text_loading']          = 'Завантаження...';

// Buttons
$_['button_address_add']    = 'Додати адресу';
$_['button_back']           = 'Назад';
$_['button_continue']       = 'Продовжити';
$_['button_cart']           = 'Придбати';
$_['button_cancel']         = 'Відмінити';
$_['button_compare']        = 'Порівняти';
$_['button_wishlist']       = 'В закладки';
$_['button_checkout']       = 'Оформлення замовлення';
$_['button_confirm']        = 'Підтвердження замовлення';
$_['button_coupon']         = 'Застосувати купон';
$_['button_delete']         = 'Видалити';
$_['button_download']       = 'Завантажити';
$_['button_edit']           = 'Редагувати';
$_['button_filter']         = 'Оберіть підкатегорію';
$_['button_new_address']    = 'Нова адреса';
$_['button_change_address'] = 'Змінити адресу';
$_['button_reviews']        = 'Відгуки';
$_['button_write']          = 'Написати відгук';
$_['button_login']          = 'Увійти';
$_['button_update']         = 'Обновити';
$_['button_remove']         = 'Видалити';
$_['button_reorder']        = 'Додаткове замовлення';
$_['button_return']         = 'Повернення товару';
$_['button_shopping']       = 'Продовжити покупки';
$_['button_search']         = 'Пошук';
$_['button_shipping']       = 'Застовувати Доставку';
$_['button_submit']         = 'Застосувати';
$_['button_guest']          = 'Оформити замовлення без реєстрації';
$_['button_view']           = 'Перегляд';
$_['button_voucher']        = 'Застосувати подарунковий сертифікат';
$_['button_upload']         = 'Завантажити файл';
$_['button_reward']         = 'Застосувати бонусні бали';
$_['button_quote']          = 'Дізнатися ціни';
$_['button_list']           = 'Список';
$_['button_grid']           = 'Сітка';
$_['button_map']            = 'Переглянути карту';

// Error
$_['error_exception']       = 'Помилка коду(%s): %s в %s на стрічці %s';
$_['error_upload_1']        = 'Розмір завантажуваного файлу превищує значення upload_max_filesize в php.ini!';
$_['error_upload_2']        = 'Завантажений файл перевищує MAX_FILE_SIZE значення, яке було вказане в налаштуваннях!';
$_['error_upload_3']        = 'Файли були завантажені лише частково!';
$_['error_upload_4']        = 'Немає файлів для завантаження!';
$_['error_upload_6']        = 'Не знайдені в тимчасовій теці!';
$_['error_upload_7']        = 'Помилка запису!';
$_['error_upload_8']        = 'Заборонено завантажувати файли цього виду!';
$_['error_upload_999']      = 'Невідома помилка!';
