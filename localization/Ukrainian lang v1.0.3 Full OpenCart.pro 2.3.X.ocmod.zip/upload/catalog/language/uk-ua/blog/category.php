<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_blog']         = 'Блог';
$_['text_refine']       = 'Виберіть підкатегорію';
$_['text_product']      = 'Статті';
$_['text_error']        = 'Категорія не знайдена!';
$_['text_empty']        = 'В цій категорії немає записів.';
$_['text_display']      = 'Вид:';
$_['text_sort']         = 'Сортування:';
$_['text_limit']        = 'На сторінці:';
$_['text_sort_date']    = 'даті';
$_['text_sort_by']      = 'Сортувати по:';
$_['text_sort_name']    = 'назві';
$_['text_sort_rated']   = 'рейтингу';
$_['text_sort_viewed']  = 'переглядах';
$_['text_views'] 	= 'Переглядів:';
$_['text_date_asc']     = 'Дата (за зростанням)';
$_['text_date_desc']    = 'Дата (за спаданням)';
$_['text_viewed_asc'] 	= 'Переглядах (за зростанням)';
$_['text_viewed_desc'] 	= 'Переглядах (за спаданням)';
$_['text_rating_asc'] 	= 'Рейтингу (за зростанням)';
$_['text_rating_desc'] 	= 'Рейтингу (за спаданням)';
$_['text_name_asc'] 	= 'Назві (за зростанням)';
$_['text_name_desc'] 	= 'Назві (за спаданням)';
$_['text_default']   	= 'По замовчуванню';

$_['button_more']       = 'Детальніше';
?>