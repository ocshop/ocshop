<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_home']          = 'Головна';
$_['text_wishlist']      = 'Закладки (%s)';
$_['text_shopping_cart'] = 'Кошик';
$_['text_category']      = 'Категорії';
$_['text_account']       = 'Особистий кабінет';
$_['text_register']      = 'Реєстрація';
$_['text_login']         = 'Авторизація';
$_['text_order']         = 'Історія замовлення';
$_['text_transaction']   = 'Операції';
$_['text_download']      = 'Файли для завантаження';
$_['text_logout']        = 'Вихід';
$_['text_checkout']      = 'Оформлення замовлення';
$_['text_search']        = 'Пошук';
$_['text_all']           = 'Перегляд всього';
$_['name_callback']      = 'Екстрений зв\'язок';