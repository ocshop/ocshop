<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_information']  = 'Інформація';
$_['text_service']      = 'Служба підтримки';
$_['text_extra']        = 'Додатково';
$_['text_contact']      = 'Зв\'язатися з нами';
$_['text_return']       = 'Повернення товару';
$_['text_sitemap']      = 'Мапа сайту';
$_['text_manufacturer'] = 'Виробники';
$_['text_voucher']      = 'Подарункові сертифікати';
$_['text_affiliate']    = 'Партнерська програма';
$_['text_special']      = 'Акції';
$_['text_account']      = 'Особистий кабінет';
$_['text_order']        = 'Історія замовлення';
$_['text_wishlist']     = 'Закладки';
$_['text_newsletter']   = 'Розсилання';
$_['text_powered']      = 'Працює на <a href="http://opencart.pro/">OPENCART.PRO</a><br /> %s &copy; %s';