<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_subject']	= '%s - Відгуки про Товар';
$_['text_waiting']	= 'Нові відгуки очікують вашої перовірки.';
$_['text_product']	= 'Товар: %s';
$_['text_reviewer']	= 'Відгук залишив: %s';
$_['text_rating']	= 'Оцінка: %s';
$_['text_review']	= 'Відгук:';