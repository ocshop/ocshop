<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_new_subject']          = '%s - Замовлення %s';
$_['text_new_greeting']         = 'Дякуємо за інтерес до товарів %s. Ваше замовлення отримано і поступив в обробку.';
$_['text_new_received']         = 'Ви отримали замовлення.';
$_['text_new_link']             = 'Для перегляду Вашого замовлення перейдіть за посиланням:';
$_['text_new_order_detail']     = 'Деталі замовлення';
$_['text_new_instruction']      = 'Інструкції';
$_['text_new_order_id']         = '№ замовлення:';
$_['text_new_date_added']       = 'Дата додавання:';
$_['text_new_order_status']     = 'Стан замовлення:';
$_['text_new_payment_method']   = 'Спосіб оплати:';
$_['text_new_shipping_method']  = 'Спосіб доставки:';
$_['text_new_email']  			= 'E-mail:';
$_['text_new_telephone']  		= 'Телефон:';
$_['text_new_ip']  				= 'IP-адреса:';
$_['text_new_payment_address']  = 'Платіжна адреса';
$_['text_new_shipping_address'] = 'Адреса доставки';
$_['text_new_products']         = 'Товари';
$_['text_new_product']          = 'Товар';
$_['text_new_model']            = 'Код товару';
$_['text_new_quantity']         = 'Кількість';
$_['text_new_price']            = 'Ціна';
$_['text_new_order_total']      = 'Сума замовлення';
$_['text_new_total']            = 'Всього';
$_['text_new_download']         = 'Після підтвердження оплати, щоб замовити товар, перейдіть за посиланням:';
$_['text_new_comment']          = 'Коментар до Вашого замовлення:';
$_['text_new_footer']           = 'Якщо у Вас є будь-які питання, дайте відповідь на це повідомлення.';
$_['text_update_subject']       = '%s - Обновлення Замовлення %s';
$_['text_update_order']         = '№ замовлення:';
$_['text_update_date_added']    = 'Дата замовлення:';
$_['text_update_order_status']  = 'Ваш Замовлення оновлений з наступним статусом:';
$_['text_update_comment']       = 'Коментар до Вашого замовлення:';
$_['text_update_link']          = 'Для перегляду Вашого замовлення перейдіть за посиланням:';
$_['text_update_footer']        = 'Якщо у Вас є будь-які питання, дайте відповідь на це повідомлення.';