<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_subject']  = '%s - Новий Пароль';
$_['text_greeting'] = 'Новий пароль був запитаний від %s.';
$_['text_password'] = 'Ваш новий пароль:';