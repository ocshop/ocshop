<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_subject']		        = '%s - Партнерська програма';
$_['text_welcome']		        = 'Ви стали партнером нашого магазину %s!';
$_['text_login']                = 'Ваш акаунт створений і Ви можете ввійти, використовуючи свій E-mail та пароль, за посиланням:';
$_['text_approval']		        = 'Ваш обліковий запис очікує підтвердження. Після підтвердження Ви можете входити в партнерський розділ нашого сайту за посиланням:';
$_['text_services']		        = 'В партнерському розділі Ви можете отримати реферальний код і реферальні посилання, відстежувати комісійну винагороду і редагувати парметри облікового запису.';
$_['text_thanks']		        = 'Дякуємо,';
$_['text_new_affiliate']        = 'Новий Партнер';
$_['text_signup']		        = 'Зареєстрований новий партнер:';
$_['text_store']		        = 'Магазин:';
$_['text_firstname']	        = 'І&#39мя:';
$_['text_lastname']		        = 'Прізвище:';
$_['text_company']		        = 'Компанія:';
$_['text_email']		        = 'E-Mail:';
$_['text_telephone']	        = 'Телефон:';
$_['text_website']		        = 'Веб-сайт:';
$_['text_order_id']             = '№ замовлення:';
$_['text_transaction_subject']  = '%s - Партнерські Комісійні';
$_['text_transaction_received'] = 'Ви отримали %s Комісійних!';
$_['text_transaction_total']    = 'Ваш баланс комісійних %s.';