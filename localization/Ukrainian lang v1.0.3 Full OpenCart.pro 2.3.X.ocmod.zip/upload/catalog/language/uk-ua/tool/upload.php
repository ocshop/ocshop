<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_upload']    = 'Файл успішно завантажений!';

// Error
$_['error_filename'] = 'Назва файлу повинна містити від 3 до 64 символів!';
$_['error_filetype'] = 'Неправильний тип файлу!';
$_['error_upload']   = 'Необхідно завантажити файл!';
