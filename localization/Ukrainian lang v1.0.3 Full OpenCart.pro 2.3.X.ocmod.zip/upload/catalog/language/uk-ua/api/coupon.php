<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_success']     = 'Ваш купон на знижку успішно застосований!';

// Error
$_['error_permission'] = 'Ви не маєте дозволу на доступ до API!';
$_['error_coupon']     = 'Купон або недійсний, або вийшов термін його дії, або досягнута межа його використання!';