<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_success']     = 'Ваша валюта успішно змінена!';

// Error
$_['error_permission'] = 'Ви не маєте дозволу на доступ до API!';
$_['error_currency']   = 'Код валюти є недійсним!';