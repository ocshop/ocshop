<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_success']       = 'Ваші покупці успішно змінені';

// Error
$_['error_permission']   = 'Ви не маєте дозволу на доступ до API!';
$_['error_firstname']    = 'Ім\'я повинне містити від 1 до 32 символів!';
$_['error_lastname']     = 'Прізвище повинне містити від 1 до 32 символів!';
$_['error_email']        = 'E-Mail адреса введена невірно!';
$_['error_telephone']    = 'Номер телефону повинен містити від 3 до 32 символів!';
$_['error_custom_field'] = '%s необхідно!';