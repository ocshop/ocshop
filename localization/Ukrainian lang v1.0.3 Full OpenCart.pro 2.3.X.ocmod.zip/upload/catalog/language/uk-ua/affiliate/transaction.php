<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']      = 'Історія виплат';

// Column
$_['column_date_added']  = 'Дата додавання';
$_['column_description'] = 'Опис';
$_['column_amount']      = 'Сума (%s)';

// Text
$_['text_account']       = 'Кабінет Партнера';
$_['text_transaction']   = 'Виплати';
$_['text_balance']       = 'Ваш поточний баланс:';
$_['text_empty']         = 'У Вас не було виплат!';