<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']   = 'Забули пароль?';

// Text
$_['text_account']    = 'Кабінет Партнера';
$_['text_forgotten']  = 'Забули пароль?';
$_['text_your_email'] = 'Ваш E-Mail';
$_['text_email']      = 'Введіть адресу електроної пошти Вашого облікового запису. Натисніть кнопку Продовжити, щоб отримати пароль на електронну пошту.';
$_['text_success']    = 'Новий пароль був надісланий на Вашу адресу електроної пошти.';

// Entry
$_['entry_email']     = 'E-Mail адреса';

// Error
$_['error_email']     = 'E-Mail адреса не знайдена, перевірте та спробуйте ще раз!';
$_['error_approved']  = 'Ваш обліковий запис потребує схвалення, перш ніж Ви зможете ввійти.';