<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title'] = 'Вихід з Кабінету Партнера';

// Text
$_['text_message']  = '<p>Ви вийшли з Кабінету Партнера.</p>';
$_['text_account']  = 'Кабінет Партнера';
$_['text_logout']   = 'Вихід';