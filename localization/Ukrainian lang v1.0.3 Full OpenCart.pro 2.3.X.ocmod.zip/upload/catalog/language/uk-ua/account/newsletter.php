<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    = 'Підписка на новини';

// Text
$_['text_account']     = 'Особистий кабінет';
$_['text_newsletter']  = 'Розсилання';
$_['text_success']     = 'Ваша підписка успішно оновлена!';

// Entry
$_['entry_newsletter'] = 'Підписатися';
