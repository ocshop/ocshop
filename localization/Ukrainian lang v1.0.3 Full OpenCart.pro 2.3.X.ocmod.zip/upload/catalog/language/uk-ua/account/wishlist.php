<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title'] = 'Мої закладки';

// Text
$_['text_account']  = 'Особистий кабінет';
$_['text_instock']  = 'В наявності';
$_['text_wishlist'] = 'Закладки (%s)';
$_['text_login']    = 'Необхідно увійти в <a href="%s">Особистий Кабінет</a> або <a href="%s">створити обліковий запис</a>, щоб зберегти товар <a href="%s">%s</a> в свої <a href="%s">закладки</a>!';
$_['text_success']  = 'Товар <a href="%s">%s</a> бул доданий в <a href="%s">закладки</a>!';
$_['text_remove']   = 'Закладки успішно обновлені!';
$_['text_empty']    = 'Ваші закладки пусті.';

// Column
$_['column_image']  = 'Зображення';
$_['column_name']   = 'Назва товару';
$_['column_model']  = 'Код товару';
$_['column_stock']  = 'Наявність';
$_['column_price']  = 'Ціна за одиницю товару';
$_['column_action'] = 'Дія';