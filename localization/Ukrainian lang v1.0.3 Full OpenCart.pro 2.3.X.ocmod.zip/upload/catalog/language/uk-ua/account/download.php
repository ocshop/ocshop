<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Файли для завантаження';

// Text
$_['text_account']      = 'Особистий кабінет';
$_['text_downloads']    = 'Файли для завантаження';
$_['text_empty']        = 'Немає доступних файлів для завантаження!';

// Column
$_['column_order_id']   = '№ Замовлення';
$_['column_name']       = 'Назва';
$_['column_size']       = 'Розмір';
$_['column_date_added'] = 'Дата додавання';