<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title'] = 'Вихід';

// Text
$_['text_message']  = '<p>Ви вийшли з Вашого Особистого Кабінету.</p><p>Ваш кошик покупок був збережений. Він буде відновлений при наступному вході у Ваш Особистий Кабінет.</p>';
$_['text_account']  = 'Особистий кабінет';
$_['text_logout']   = 'Вихід';