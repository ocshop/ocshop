<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']                = 'Авторизація';

// Text
$_['text_account']                 = 'Акаунт';
$_['text_login']                   = 'Авторизація';
$_['text_new_customer']            = 'Новий покупець';
$_['text_register']                = 'Реєстрація';
$_['text_register_account']        = 'Створення облікового запису допоможе робити покупки швидше та зручніше. Ви також зможете відслідковувати статус свого замовлення, користуватися закладками, бачити свої попередні замовлення або отримувати знижку як наш постійний покупець.';
$_['text_returning_customer']      = 'Постійний покупець';
$_['text_i_am_returning_customer'] = 'Я здійснював тут покупки раніше та реєструвався';
$_['text_forgotten']               = 'Забули пароль?';

// Entry
$_['entry_email']                  = 'E-Mail адреса';
$_['entry_password']               = 'Пароль';

// Error
$_['error_login']                  = 'Не знайдено введену адресу E-Mail і/або пароль вказано невірно.';
$_['error_attempts']               = 'Ваш обліковий запис превищив допустиму кількість спроб входу в систему. Будь ласка, спробуйте знову через 1 годину.';
$_['error_approved']               = 'Ви зможете увійти після перевірки облікового запису адміністрацією крамниці.';