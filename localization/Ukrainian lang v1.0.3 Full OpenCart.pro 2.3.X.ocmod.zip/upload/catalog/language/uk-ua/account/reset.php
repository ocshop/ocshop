<?php
// *	@copyright	OPENCART.PRO 2011 - 2016.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']  = 'Змінити пароль';

// Text
$_['text_account']   = 'Особистий кабінет';
$_['text_password']  = 'Вкажіть ваш новий пароль.';
$_['text_success']   = 'Ваш пароль успішно змінено.';

// Entry
$_['entry_password'] = 'Пароль';
$_['entry_confirm']  = 'Підтвердіть пароль';

// Error
$_['error_password'] = 'Пароль повинен мімтити від 4 до 20 символів!';
$_['error_confirm']  = 'Паролі не співпадають!';
$_['error_code']     = 'Код зміни пароля є недійсним або був використаний раніше!';