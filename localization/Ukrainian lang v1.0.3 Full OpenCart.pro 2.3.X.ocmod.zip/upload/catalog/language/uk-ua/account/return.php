<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']      = 'Повернення товару';

// Text
$_['text_account']       = 'Акаунт';
$_['text_return']        = 'Інформація про повернення';
$_['text_return_detail'] = 'Датальна інформація про поверннення';
$_['text_description']   = 'Будь ласка, заповніть форму запиту на повернення товару.';
$_['text_order']         = 'Інформація про замовлення';
$_['text_product']       = 'Інформація про товар та причина повернення';
$_['text_message']       = '<p>Ви відправили запит на повернення.</p><p> Повідомлення про статус запиту будуть приходити на ваш e-mail.</p>';
$_['text_return_id']     = '№ запиту на повернення:';
$_['text_order_id']      = '№ замовлення:';
$_['text_date_ordered']  = 'Дата замовлення:';
$_['text_status']        = 'Статус:';
$_['text_date_added']    = 'Дата додавання:';
$_['text_comment']       = 'Коментар по поверненню';
$_['text_history']       = 'Історія повернень';
$_['text_empty']         = 'В Вас не було раніше повернень товарів!';
$_['text_agree']         = 'Я прочитав(ла) <a href="%s" class="agree"><b>%s</b></a> та згідний(а) з умовами';

// Column
$_['column_return_id']   = '№ Запиту на повернення';
$_['column_order_id']    = '№ Замовлення';
$_['column_status']      = 'Статус';
$_['column_date_added']  = 'Дата додавання';
$_['column_customer']    = 'Покупець';
$_['column_product']     = 'Назва товару';
$_['column_model']       = 'Код товару';
$_['column_quantity']    = 'Кількість';
$_['column_price']       = 'Ціна';
$_['column_opened']      = 'Відчинено';
$_['column_comment']     = 'Коментар';
$_['column_reason']      = 'Причина';
$_['column_action']      = 'Дія';

// Entry
$_['entry_order_id']     = '№ Замовлення';
$_['entry_date_ordered'] = 'Дата замовлення';
$_['entry_firstname']    = 'Імя';
$_['entry_lastname']     = 'Прізвище';
$_['entry_email']        = 'E-Mail';
$_['entry_telephone']    = 'Телефон';
$_['entry_product']      = 'Назва товару';
$_['entry_model']        = 'Код товару';
$_['entry_quantity']     = 'Кількість';
$_['entry_reason']       = 'Причина повернення';
$_['entry_opened']       = 'Товар розпакований';
$_['entry_fault_detail'] = 'Опис дефектів';

// Error
$_['text_error']         = 'Запит на повернення не знайдений!';
$_['error_order_id']     = 'Не вказаний № замовлення!';
$_['error_firstname']    = 'І\'мя повинне містити від 1 до 32 символів!';
$_['error_lastname']     = 'Прізвище повинне містити від 1 до 32 символів!';
$_['error_email']        = 'E-Mail адреса введена невірно!';
$_['error_telephone']    = 'Номер телефону повинен містити від 3 до 32 символів!';
$_['error_product']      = 'Найменування товару повинне містити від 3 до 255 символів!';
$_['error_model']        = 'Код Товару повинен містити від 3 до 64 символів!';
$_['error_reason']       = 'Необхідно вказати причину повернення товару!';
$_['error_agree']        = 'Ви повинні підтвердити згоду з %s!';