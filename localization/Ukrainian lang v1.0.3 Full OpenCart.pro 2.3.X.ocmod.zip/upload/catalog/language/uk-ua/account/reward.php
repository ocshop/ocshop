<?php
// *	@copyright	OPENCART.PRO 2011 - 2015.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']      = 'Бонусні бали';

// Column
$_['column_date_added']  = 'Дата додавання';
$_['column_description'] = 'Опис';
$_['column_points']      = 'Бонусні бали';

// Text
$_['text_account']       = 'Особистий кабінет';
$_['text_reward']        = 'Бонусні бали';
$_['text_total']         = 'Накопичено бонусних балів:';
$_['text_empty']         = 'В Вас немає бонусних балів!';