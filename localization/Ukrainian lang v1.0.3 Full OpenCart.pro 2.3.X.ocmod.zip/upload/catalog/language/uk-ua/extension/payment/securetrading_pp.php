<?php
// *	@copyright	OPENCART.PRO 2011 - 2016.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt


$_['text_title'] = 'Credit / Debit card';
$_['button_confirm'] = 'Підтвердити';

$_['text_postcode_check'] = 'Postcode check: %s';
$_['text_security_code_check'] = 'CVV2 check: %s';
$_['text_address_check'] = 'Address check: %s';
$_['text_not_given'] = 'Not given';
$_['text_not_checked'] = 'Not checked';
$_['text_match'] = 'Matched';
$_['text_not_match'] = 'Not matched';
$_['text_payment_details'] = 'Деталі оплати';

$_['entry_card_type'] = 'Тип карти';