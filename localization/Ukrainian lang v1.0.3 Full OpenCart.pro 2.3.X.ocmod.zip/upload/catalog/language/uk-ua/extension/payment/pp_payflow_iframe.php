<?php
// *	@copyright	OPENCART.PRO 2011 - 2016.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_title']				= 'Кредитні и Дебетові карти';
$_['text_secure_connection']	= 'Встановлення безпечного з\'єднання ...';

// Error
$_['error_connection']			= 'Помилка з\'єднання із PayPal. Якщо помилка повториться зверніться за допомогою до адміністрації магазину або виберіть інший спосіб оплати.';