<?php
// *	@copyright	OPENCART.PRO 2011 - 2016.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_title']				= 'Credit Card / Debit Card (SagePay)';
$_['text_credit_card']			= 'Інформація платіжної карти';

// Entry
$_['entry_cc_owner']			= 'Card Owner';
$_['entry_cc_number']			= 'Номер карти';
$_['entry_cc_expire_date']		= 'Дата закінчення строку дії карти';
$_['entry_cc_cvv2']				= 'Код безпеки (CVV2)';