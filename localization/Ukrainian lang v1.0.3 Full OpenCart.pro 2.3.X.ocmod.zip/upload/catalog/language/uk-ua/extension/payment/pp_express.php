<?php
// *	@copyright	OPENCART.PRO 2011 - 2016.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['express_text_title']      = 'Підтвердження замовлення';

// Text
$_['text_title']              = 'PayPal Express (включаючи Кредитні і Дебетові карти)';
$_['button_continue']         = 'Продовжити';
$_['text_cart']               = 'Кошик покупок';
$_['text_shipping_updated']   = 'Доставка оновлена';
$_['text_trial']              = 'Сума: %s; Періодичність: %s %s; Кіль-сть платежів: %s, Далі ';
$_['text_recurring']          = 'Сума: %s Періодичність: %s %s';
$_['text_recurring_item']     = 'Періодичні платежі';
$_['text_length']             = ' Кіль=сть платежів: %s';

// Entry
$_['express_entry_coupon']    = 'Введіть код купона:';

// Button
$_['button_express_coupon']   = 'Додати';
$_['button_express_confirm']  = 'Підтвердити';
$_['button_express_login']    = 'Увійти в PayPal';
$_['button_express_shipping'] = 'Оновити доставку';
$_['button_cancel_recurring'] = 'Скасувати платежі';

// Error
$_['error_heading_title']	  = 'Виникла помилка';
$_['error_too_many_failures'] = 'В процесі оплати сталася помилка';