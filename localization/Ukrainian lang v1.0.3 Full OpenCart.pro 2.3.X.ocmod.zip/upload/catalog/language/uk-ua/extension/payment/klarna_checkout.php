<?php
// *	@copyright	OPENCART.PRO 2011 - 2016.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']				   = 'Klarna Checkout';
$_['heading_title_success']		   = 'Your Klarna Checkout order has been placed!';

// Text
$_['text_title']				   = 'Klarna Checkout';
$_['text_basket']				   = 'Shopping Cart';
$_['text_checkout']				   = 'Checkout';
$_['text_success']				   = 'Success';
$_['text_choose_shipping_method']  = 'Choose shipping method';
$_['text_sales_tax']			   = 'Sales Tax';