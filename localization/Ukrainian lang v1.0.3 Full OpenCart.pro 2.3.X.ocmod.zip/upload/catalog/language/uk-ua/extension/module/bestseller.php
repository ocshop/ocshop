<?php
// Heading
$_['heading_title'] = 'Хіт продажу';

// Text
$_['text_tax']      = 'Без ПДВ:';

