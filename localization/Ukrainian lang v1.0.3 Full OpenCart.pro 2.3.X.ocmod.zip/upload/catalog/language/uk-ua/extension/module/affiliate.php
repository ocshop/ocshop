<?php
// *	@copyright	OPENCART.PRO 2011 - 2016.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    = 'Партнерський розділ';

// Text
$_['text_register']    = 'Реєстрація';
$_['text_login']       = 'Вхід';
$_['text_logout']      = 'Вихід';
$_['text_forgotten']   = 'Забули пароль?';
$_['text_account']     = 'Моя інформація';
$_['text_edit']        = 'Редагувати інформацію';
$_['text_password']    = 'Пароль';
$_['text_payment']     = 'Спосіб оплати';
$_['text_tracking']    = 'Реферальний код';
$_['text_transaction'] = 'Операції';
