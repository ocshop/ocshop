<?php
// *	@copyright	OPENCART.PRO 2011 - 2016.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Calculator
$_['text_checkout_title']      = 'Оплата в розстрочку';
$_['text_choose_plan']         = 'Виберіть свій план';
$_['text_choose_deposit']      = 'Виберіть свій депозит';
$_['text_monthly_payments']    = 'Щомісячні виплати';
$_['text_months']              = 'Місяці';
$_['text_term']                = 'Термін';
$_['text_deposit']             = 'Депозит';
$_['text_credit_amount']       = 'Вартість кредиту';
$_['text_amount_payable']      = 'Сума до сплати';
$_['text_total_interest']      = 'Загальний розмір процентів';
$_['text_monthly_installment'] = 'Щомісячний платіж';
$_['text_redirection']         = 'Ви будете перенаправлені на Менеджера, щоб завершити цю фінансову заявку, коли ви підтвердите своє замовлення';
