<?php
// *	@copyright	OPENCART.PRO 2011 - 2016.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_total_shipping']		= 'Shipping';
$_['text_total_discount']		= 'Discount';
$_['text_total_tax']			= 'Tax';
$_['text_total_sub']			= 'Sub-total';
$_['text_total']				= 'Total';
$_['text_smp_id']				= 'Selling Manager sale ID: ';
$_['text_buyer']				= 'Buyer username: ';
