<?php
// *	@copyright	OPENCART.PRO 2011 - 2016.
// *	@forum	http://forum.opencart.pro
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_paid_amazon'] 			= 'Виплата на Amazon';
$_['text_total_shipping'] 		= 'Доставка';
$_['text_total_shipping_tax'] 	= 'Доставка ПДВ';
$_['text_total_giftwrap'] 		= 'Подарункова упаковка';
$_['text_total_giftwrap_tax'] 	= 'Подарункова упаковка ПДВ';
$_['text_total_sub'] 			= 'Сума';
$_['text_tax'] 					= 'Без ПДВ';
$_['text_total'] 				= 'Загалом';